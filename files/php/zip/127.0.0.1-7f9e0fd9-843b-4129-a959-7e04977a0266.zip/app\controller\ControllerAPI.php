<?php
namespace App\Controller;

use App\Model\Cachorro_1;
use App\Model\Cachorro_1s;
use App\Model\Elefante_1;
use App\Model\Elefante_1s;
use App\Model\Gato_1;
use App\Model\Gato_1s;
use App\Model\Rato_1;
use App\Model\Rato_1s;
use App\Model\Lobo_1;
use App\Model\Lobo_1s;
use App\Model\Girafa_1;
use App\Model\Girafa_1s;
use App\Model\Camelo_1;
use App\Model\Camelo_1s;
use App\Model\Jacare_1;
use App\Model\Jacare_1s;
use App\Data\DAO;
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require DIRREQ . '/src/vendor/autoload.php';

class ControllerAPI extends eController
{
    public function __construct()
    {
        parent::__construct();

        header('Content-Type: application/json');
    }

    public function cachorro_1s()
    {
        try
        {
            $cachorro_1s = new Cachorro_1s();
            $cachorro_1s->read();
    
            $this->result["result"] = $cachorro_1s->getList();
            $this->result["error"] = null;
        }
        catch(\Exception $ex)
        {
            $this->result["result"] = null;
            $this->result["error"] = $ex->getMessage();
        }
    
        print_r(json_encode($this->result));
    }
    
    public function cachorro_1($cachorro_1Id)
    {
        try
        {
            $cachorro_1 = new Cachorro_1();
            $cachorro_1->setId($cachorro_1Id);
            $cachorro_1->read();
    
            $this->result["result"] = $cachorro_1;
            $this->result["error"] = null;
        }
        catch(\Exception $ex)
        {
            $this->result["result"] = null;
            $this->result["error"] = $ex->getMessage();
        }
    
        print_r(json_encode($this->result));
    }
    
    public function add_cachorro_1()
    {
        $dao = null;
        try
        {
            $cachorro_1 = new Cachorro_1();
            if(!is_null($_POST["raca_1"]) && isset($_POST["raca_1"]))
            {
                $cachorro_1->setRaca_1($_POST["raca_1"]);
            }
            $dao = new DAO();
            $dao->startTransaction();
    
            $cachorro_1Id =$cachorro_1->insert();

            if($cachorro_1Id > 0)
            {
                $dao->commitTransaction();

                $this->result["result"] = $cachorro_1Id;
                $this->result["error"] = null;
            }
            else
            {
                if (!is_null($dao))
            {
                $dao->rollbackTransaction();
            }
            }
        }
        catch(\Exception $ex)
        {
            if (!is_null($dao))
            {
                $dao->rollbackTransaction();
            }

            $this->result["result"] = null;
            $this->result["error"] = $ex->getMessage();
        }

        print_r(json_encode($this->result));
    }

    public function edit_cachorro_1($cachorro_1Id)
    {
        $dao = null;
        try
        {
            $cachorro_1 = new Cachorro_1();
            $cachorro_1->read($cachorro_1Id);
    
            if(!is_null($_POST["raca_1"]) && isset($_POST["raca_1"]))
            {
                $cachorro_1->setRaca_1($_POST["raca_1"]);
            }
            
            $dao = new DAO();
            $dao->startTransaction();
    
            if($cachorro_1->update() == true)
            {
                $dao->commitTransaction();
    
                $this->result["result"] = true;
                $this->result["error"] = null;
            }
            else
            {
                if (!is_null($dao))
            {
                $dao->rollbackTransaction();
            }
            }
        }
        catch(\Exception $ex)
        {
            if (!is_null($dao))
            {
                $dao->rollbackTransaction();
            }
    
            $this->result["result"] = null;
            $this->result["error"] = $ex->getMessage();
        }
    
        print_r(json_encode($this->result));
    }
    
    public function delete_cachorro_1($cachorro_1Id)
    {
        $dao = null;
        try
        {
            $cachorro_1 = new Cachorro_1();
            $cachorro_1->read($cachorro_1Id);
    
            $dao = new DAO();
            $dao->startTransaction();
    
            if($cachorro_1->delete() == true)
            {
                $dao->commitTransaction();
    
                $this->result["result"] = true;
                $this->result["error"] = null;
            }
            else
            {
                if (!is_null($dao))
            {
                $dao->rollbackTransaction();
            }

                $this->result["result"] = false;
                $this->result["error"] = "Could not delete Cachorro_1!";
            }
        }
        catch(\Exception $ex)
        {
            if (!is_null($dao))
            {
                $dao->rollbackTransaction();
            }
    
            $this->result["result"] = null;
            $this->result["error"] = $ex->getMessage();
        }
    
        print_r(json_encode($this->result));
    }

    public function elefante_1s()
    {
        try
        {
            $elefante_1s = new Elefante_1s();
            $elefante_1s->read();
    
            $this->result["result"] = $elefante_1s->getList();
            $this->result["error"] = null;
        }
        catch(\Exception $ex)
        {
            $this->result["result"] = null;
            $this->result["error"] = $ex->getMessage();
        }
    
        print_r(json_encode($this->result));
    }
    
    public function elefante_1($elefante_1Id)
    {
        try
        {
            $elefante_1 = new Elefante_1();
            $elefante_1->setId($elefante_1Id);
            $elefante_1->read();
    
            $this->result["result"] = $elefante_1;
            $this->result["error"] = null;
        }
        catch(\Exception $ex)
        {
            $this->result["result"] = null;
            $this->result["error"] = $ex->getMessage();
        }
    
        print_r(json_encode($this->result));
    }
    
    public function add_elefante_1()
    {
        $dao = null;
        try
        {
            $elefante_1 = new Elefante_1();
            if(!is_null($_POST["tamanho_1"]) && isset($_POST["tamanho_1"]))
            {
                $elefante_1->setTamanho_1($_POST["tamanho_1"]);
            }
            $dao = new DAO();
            $dao->startTransaction();
    
            $elefante_1Id =$elefante_1->insert();

            if($elefante_1Id > 0)
            {
                $dao->commitTransaction();

                $this->result["result"] = $elefante_1Id;
                $this->result["error"] = null;
            }
            else
            {
                if (!is_null($dao))
            {
                $dao->rollbackTransaction();
            }
            }
        }
        catch(\Exception $ex)
        {
            if (!is_null($dao))
            {
                $dao->rollbackTransaction();
            }

            $this->result["result"] = null;
            $this->result["error"] = $ex->getMessage();
        }

        print_r(json_encode($this->result));
    }

    public function edit_elefante_1($elefante_1Id)
    {
        $dao = null;
        try
        {
            $elefante_1 = new Elefante_1();
            $elefante_1->read($elefante_1Id);
    
            if(!is_null($_POST["tamanho_1"]) && isset($_POST["tamanho_1"]))
            {
                $elefante_1->setTamanho_1($_POST["tamanho_1"]);
            }
            
            $dao = new DAO();
            $dao->startTransaction();
    
            if($elefante_1->update() == true)
            {
                $dao->commitTransaction();
    
                $this->result["result"] = true;
                $this->result["error"] = null;
            }
            else
            {
                if (!is_null($dao))
            {
                $dao->rollbackTransaction();
            }
            }
        }
        catch(\Exception $ex)
        {
            if (!is_null($dao))
            {
                $dao->rollbackTransaction();
            }
    
            $this->result["result"] = null;
            $this->result["error"] = $ex->getMessage();
        }
    
        print_r(json_encode($this->result));
    }
    
    public function delete_elefante_1($elefante_1Id)
    {
        $dao = null;
        try
        {
            $elefante_1 = new Elefante_1();
            $elefante_1->read($elefante_1Id);
    
            $dao = new DAO();
            $dao->startTransaction();
    
            if($elefante_1->delete() == true)
            {
                $dao->commitTransaction();
    
                $this->result["result"] = true;
                $this->result["error"] = null;
            }
            else
            {
                if (!is_null($dao))
            {
                $dao->rollbackTransaction();
            }

                $this->result["result"] = false;
                $this->result["error"] = "Could not delete Elefante_1!";
            }
        }
        catch(\Exception $ex)
        {
            if (!is_null($dao))
            {
                $dao->rollbackTransaction();
            }
    
            $this->result["result"] = null;
            $this->result["error"] = $ex->getMessage();
        }
    
        print_r(json_encode($this->result));
    }

    public function gato_1s()
    {
        try
        {
            $gato_1s = new Gato_1s();
            $gato_1s->read();
    
            $this->result["result"] = $gato_1s->getList();
            $this->result["error"] = null;
        }
        catch(\Exception $ex)
        {
            $this->result["result"] = null;
            $this->result["error"] = $ex->getMessage();
        }
    
        print_r(json_encode($this->result));
    }
    
    public function gato_1($gato_1Id)
    {
        try
        {
            $gato_1 = new Gato_1();
            $gato_1->setId($gato_1Id);
            $gato_1->read();
    
            $this->result["result"] = $gato_1;
            $this->result["error"] = null;
        }
        catch(\Exception $ex)
        {
            $this->result["result"] = null;
            $this->result["error"] = $ex->getMessage();
        }
    
        print_r(json_encode($this->result));
    }
    
    public function add_gato_1()
    {
        $dao = null;
        try
        {
            $gato_1 = new Gato_1();
            if(!is_null($_POST["cor_1"]) && isset($_POST["cor_1"]))
            {
                $gato_1->setCor_1($_POST["cor_1"]);
            }
            $dao = new DAO();
            $dao->startTransaction();
    
            $gato_1Id =$gato_1->insert();

            if($gato_1Id > 0)
            {
                $dao->commitTransaction();

                $this->result["result"] = $gato_1Id;
                $this->result["error"] = null;
            }
            else
            {
                if (!is_null($dao))
            {
                $dao->rollbackTransaction();
            }
            }
        }
        catch(\Exception $ex)
        {
            if (!is_null($dao))
            {
                $dao->rollbackTransaction();
            }

            $this->result["result"] = null;
            $this->result["error"] = $ex->getMessage();
        }

        print_r(json_encode($this->result));
    }

    public function edit_gato_1($gato_1Id)
    {
        $dao = null;
        try
        {
            $gato_1 = new Gato_1();
            $gato_1->read($gato_1Id);
    
            if(!is_null($_POST["cor_1"]) && isset($_POST["cor_1"]))
            {
                $gato_1->setCor_1($_POST["cor_1"]);
            }
            
            $dao = new DAO();
            $dao->startTransaction();
    
            if($gato_1->update() == true)
            {
                $dao->commitTransaction();
    
                $this->result["result"] = true;
                $this->result["error"] = null;
            }
            else
            {
                if (!is_null($dao))
            {
                $dao->rollbackTransaction();
            }
            }
        }
        catch(\Exception $ex)
        {
            if (!is_null($dao))
            {
                $dao->rollbackTransaction();
            }
    
            $this->result["result"] = null;
            $this->result["error"] = $ex->getMessage();
        }
    
        print_r(json_encode($this->result));
    }
    
    public function delete_gato_1($gato_1Id)
    {
        $dao = null;
        try
        {
            $gato_1 = new Gato_1();
            $gato_1->read($gato_1Id);
    
            $dao = new DAO();
            $dao->startTransaction();
    
            if($gato_1->delete() == true)
            {
                $dao->commitTransaction();
    
                $this->result["result"] = true;
                $this->result["error"] = null;
            }
            else
            {
                if (!is_null($dao))
            {
                $dao->rollbackTransaction();
            }

                $this->result["result"] = false;
                $this->result["error"] = "Could not delete Gato_1!";
            }
        }
        catch(\Exception $ex)
        {
            if (!is_null($dao))
            {
                $dao->rollbackTransaction();
            }
    
            $this->result["result"] = null;
            $this->result["error"] = $ex->getMessage();
        }
    
        print_r(json_encode($this->result));
    }

    public function rato_1s()
    {
        try
        {
            $rato_1s = new Rato_1s();
            $rato_1s->read();
    
            $this->result["result"] = $rato_1s->getList();
            $this->result["error"] = null;
        }
        catch(\Exception $ex)
        {
            $this->result["result"] = null;
            $this->result["error"] = $ex->getMessage();
        }
    
        print_r(json_encode($this->result));
    }
    
    public function rato_1($rato_1Id)
    {
        try
        {
            $rato_1 = new Rato_1();
            $rato_1->setId($rato_1Id);
            $rato_1->read();
    
            $this->result["result"] = $rato_1;
            $this->result["error"] = null;
        }
        catch(\Exception $ex)
        {
            $this->result["result"] = null;
            $this->result["error"] = $ex->getMessage();
        }
    
        print_r(json_encode($this->result));
    }
    
    public function add_rato_1()
    {
        $dao = null;
        try
        {
            $rato_1 = new Rato_1();
            if(!is_null($_POST["limpo_1"]) && isset($_POST["limpo_1"]))
            {
                $rato_1->setLimpo_1($_POST["limpo_1"]);
            }
            $dao = new DAO();
            $dao->startTransaction();
    
            $rato_1Id =$rato_1->insert();

            if($rato_1Id > 0)
            {
                $dao->commitTransaction();

                $this->result["result"] = $rato_1Id;
                $this->result["error"] = null;
            }
            else
            {
                if (!is_null($dao))
            {
                $dao->rollbackTransaction();
            }
            }
        }
        catch(\Exception $ex)
        {
            if (!is_null($dao))
            {
                $dao->rollbackTransaction();
            }

            $this->result["result"] = null;
            $this->result["error"] = $ex->getMessage();
        }

        print_r(json_encode($this->result));
    }

    public function edit_rato_1($rato_1Id)
    {
        $dao = null;
        try
        {
            $rato_1 = new Rato_1();
            $rato_1->read($rato_1Id);
    
            if(!is_null($_POST["limpo_1"]) && isset($_POST["limpo_1"]))
            {
                $rato_1->setLimpo_1($_POST["limpo_1"]);
            }
            
            $dao = new DAO();
            $dao->startTransaction();
    
            if($rato_1->update() == true)
            {
                $dao->commitTransaction();
    
                $this->result["result"] = true;
                $this->result["error"] = null;
            }
            else
            {
                if (!is_null($dao))
            {
                $dao->rollbackTransaction();
            }
            }
        }
        catch(\Exception $ex)
        {
            if (!is_null($dao))
            {
                $dao->rollbackTransaction();
            }
    
            $this->result["result"] = null;
            $this->result["error"] = $ex->getMessage();
        }
    
        print_r(json_encode($this->result));
    }
    
    public function delete_rato_1($rato_1Id)
    {
        $dao = null;
        try
        {
            $rato_1 = new Rato_1();
            $rato_1->read($rato_1Id);
    
            $dao = new DAO();
            $dao->startTransaction();
    
            if($rato_1->delete() == true)
            {
                $dao->commitTransaction();
    
                $this->result["result"] = true;
                $this->result["error"] = null;
            }
            else
            {
                if (!is_null($dao))
            {
                $dao->rollbackTransaction();
            }

                $this->result["result"] = false;
                $this->result["error"] = "Could not delete Rato_1!";
            }
        }
        catch(\Exception $ex)
        {
            if (!is_null($dao))
            {
                $dao->rollbackTransaction();
            }
    
            $this->result["result"] = null;
            $this->result["error"] = $ex->getMessage();
        }
    
        print_r(json_encode($this->result));
    }

    public function lobo_1s()
    {
        try
        {
            $lobo_1s = new Lobo_1s();
            $lobo_1s->read();
    
            $this->result["result"] = $lobo_1s->getList();
            $this->result["error"] = null;
        }
        catch(\Exception $ex)
        {
            $this->result["result"] = null;
            $this->result["error"] = $ex->getMessage();
        }
    
        print_r(json_encode($this->result));
    }
    
    public function lobo_1($lobo_1Id)
    {
        try
        {
            $lobo_1 = new Lobo_1();
            $lobo_1->setId($lobo_1Id);
            $lobo_1->read();
    
            $this->result["result"] = $lobo_1;
            $this->result["error"] = null;
        }
        catch(\Exception $ex)
        {
            $this->result["result"] = null;
            $this->result["error"] = $ex->getMessage();
        }
    
        print_r(json_encode($this->result));
    }
    
    public function add_lobo_1()
    {
        $dao = null;
        try
        {
            $lobo_1 = new Lobo_1();
            if(!is_null($_POST["matilha_1"]) && isset($_POST["matilha_1"]))
            {
                $lobo_1->setMatilha_1($_POST["matilha_1"]);
            }
            $dao = new DAO();
            $dao->startTransaction();
    
            $lobo_1Id =$lobo_1->insert();

            if($lobo_1Id > 0)
            {
                $dao->commitTransaction();

                $this->result["result"] = $lobo_1Id;
                $this->result["error"] = null;
            }
            else
            {
                if (!is_null($dao))
            {
                $dao->rollbackTransaction();
            }
            }
        }
        catch(\Exception $ex)
        {
            if (!is_null($dao))
            {
                $dao->rollbackTransaction();
            }

            $this->result["result"] = null;
            $this->result["error"] = $ex->getMessage();
        }

        print_r(json_encode($this->result));
    }

    public function edit_lobo_1($lobo_1Id)
    {
        $dao = null;
        try
        {
            $lobo_1 = new Lobo_1();
            $lobo_1->read($lobo_1Id);
    
            if(!is_null($_POST["matilha_1"]) && isset($_POST["matilha_1"]))
            {
                $lobo_1->setMatilha_1($_POST["matilha_1"]);
            }
            
            $dao = new DAO();
            $dao->startTransaction();
    
            if($lobo_1->update() == true)
            {
                $dao->commitTransaction();
    
                $this->result["result"] = true;
                $this->result["error"] = null;
            }
            else
            {
                if (!is_null($dao))
            {
                $dao->rollbackTransaction();
            }
            }
        }
        catch(\Exception $ex)
        {
            if (!is_null($dao))
            {
                $dao->rollbackTransaction();
            }
    
            $this->result["result"] = null;
            $this->result["error"] = $ex->getMessage();
        }
    
        print_r(json_encode($this->result));
    }
    
    public function delete_lobo_1($lobo_1Id)
    {
        $dao = null;
        try
        {
            $lobo_1 = new Lobo_1();
            $lobo_1->read($lobo_1Id);
    
            $dao = new DAO();
            $dao->startTransaction();
    
            if($lobo_1->delete() == true)
            {
                $dao->commitTransaction();
    
                $this->result["result"] = true;
                $this->result["error"] = null;
            }
            else
            {
                if (!is_null($dao))
            {
                $dao->rollbackTransaction();
            }

                $this->result["result"] = false;
                $this->result["error"] = "Could not delete Lobo_1!";
            }
        }
        catch(\Exception $ex)
        {
            if (!is_null($dao))
            {
                $dao->rollbackTransaction();
            }
    
            $this->result["result"] = null;
            $this->result["error"] = $ex->getMessage();
        }
    
        print_r(json_encode($this->result));
    }

    public function girafa_1s()
    {
        try
        {
            $girafa_1s = new Girafa_1s();
            $girafa_1s->read();
    
            $this->result["result"] = $girafa_1s->getList();
            $this->result["error"] = null;
        }
        catch(\Exception $ex)
        {
            $this->result["result"] = null;
            $this->result["error"] = $ex->getMessage();
        }
    
        print_r(json_encode($this->result));
    }
    
    public function girafa_1($girafa_1Id)
    {
        try
        {
            $girafa_1 = new Girafa_1();
            $girafa_1->setId($girafa_1Id);
            $girafa_1->read();
    
            $this->result["result"] = $girafa_1;
            $this->result["error"] = null;
        }
        catch(\Exception $ex)
        {
            $this->result["result"] = null;
            $this->result["error"] = $ex->getMessage();
        }
    
        print_r(json_encode($this->result));
    }
    
    public function add_girafa_1()
    {
        $dao = null;
        try
        {
            $girafa_1 = new Girafa_1();
            if(!is_null($_POST["amazonense_1"]) && isset($_POST["amazonense_1"]))
            {
                $girafa_1->setAmazonense_1($_POST["amazonense_1"]);
            }
            $dao = new DAO();
            $dao->startTransaction();
    
            $girafa_1Id =$girafa_1->insert();

            if($girafa_1Id > 0)
            {
                $dao->commitTransaction();

                $this->result["result"] = $girafa_1Id;
                $this->result["error"] = null;
            }
            else
            {
                if (!is_null($dao))
            {
                $dao->rollbackTransaction();
            }
            }
        }
        catch(\Exception $ex)
        {
            if (!is_null($dao))
            {
                $dao->rollbackTransaction();
            }

            $this->result["result"] = null;
            $this->result["error"] = $ex->getMessage();
        }

        print_r(json_encode($this->result));
    }

    public function edit_girafa_1($girafa_1Id)
    {
        $dao = null;
        try
        {
            $girafa_1 = new Girafa_1();
            $girafa_1->read($girafa_1Id);
    
            if(!is_null($_POST["amazonense_1"]) && isset($_POST["amazonense_1"]))
            {
                $girafa_1->setAmazonense_1($_POST["amazonense_1"]);
            }
            
            $dao = new DAO();
            $dao->startTransaction();
    
            if($girafa_1->update() == true)
            {
                $dao->commitTransaction();
    
                $this->result["result"] = true;
                $this->result["error"] = null;
            }
            else
            {
                if (!is_null($dao))
            {
                $dao->rollbackTransaction();
            }
            }
        }
        catch(\Exception $ex)
        {
            if (!is_null($dao))
            {
                $dao->rollbackTransaction();
            }
    
            $this->result["result"] = null;
            $this->result["error"] = $ex->getMessage();
        }
    
        print_r(json_encode($this->result));
    }
    
    public function delete_girafa_1($girafa_1Id)
    {
        $dao = null;
        try
        {
            $girafa_1 = new Girafa_1();
            $girafa_1->read($girafa_1Id);
    
            $dao = new DAO();
            $dao->startTransaction();
    
            if($girafa_1->delete() == true)
            {
                $dao->commitTransaction();
    
                $this->result["result"] = true;
                $this->result["error"] = null;
            }
            else
            {
                if (!is_null($dao))
            {
                $dao->rollbackTransaction();
            }

                $this->result["result"] = false;
                $this->result["error"] = "Could not delete Girafa_1!";
            }
        }
        catch(\Exception $ex)
        {
            if (!is_null($dao))
            {
                $dao->rollbackTransaction();
            }
    
            $this->result["result"] = null;
            $this->result["error"] = $ex->getMessage();
        }
    
        print_r(json_encode($this->result));
    }

    public function camelo_1s()
    {
        try
        {
            $camelo_1s = new Camelo_1s();
            $camelo_1s->read();
    
            $this->result["result"] = $camelo_1s->getList();
            $this->result["error"] = null;
        }
        catch(\Exception $ex)
        {
            $this->result["result"] = null;
            $this->result["error"] = $ex->getMessage();
        }
    
        print_r(json_encode($this->result));
    }
    
    public function camelo_1($camelo_1Id)
    {
        try
        {
            $camelo_1 = new Camelo_1();
            $camelo_1->setId($camelo_1Id);
            $camelo_1->read();
    
            $this->result["result"] = $camelo_1;
            $this->result["error"] = null;
        }
        catch(\Exception $ex)
        {
            $this->result["result"] = null;
            $this->result["error"] = $ex->getMessage();
        }
    
        print_r(json_encode($this->result));
    }
    
    public function add_camelo_1()
    {
        $dao = null;
        try
        {
            $camelo_1 = new Camelo_1();
            if(!is_null($_POST["corcova_1"]) && isset($_POST["corcova_1"]))
            {
                $camelo_1->setCorcova_1($_POST["corcova_1"]);
            }
            $dao = new DAO();
            $dao->startTransaction();
    
            $camelo_1Id =$camelo_1->insert();

            if($camelo_1Id > 0)
            {
                $dao->commitTransaction();

                $this->result["result"] = $camelo_1Id;
                $this->result["error"] = null;
            }
            else
            {
                if (!is_null($dao))
            {
                $dao->rollbackTransaction();
            }
            }
        }
        catch(\Exception $ex)
        {
            if (!is_null($dao))
            {
                $dao->rollbackTransaction();
            }

            $this->result["result"] = null;
            $this->result["error"] = $ex->getMessage();
        }

        print_r(json_encode($this->result));
    }

    public function edit_camelo_1($camelo_1Id)
    {
        $dao = null;
        try
        {
            $camelo_1 = new Camelo_1();
            $camelo_1->read($camelo_1Id);
    
            if(!is_null($_POST["corcova_1"]) && isset($_POST["corcova_1"]))
            {
                $camelo_1->setCorcova_1($_POST["corcova_1"]);
            }
            
            $dao = new DAO();
            $dao->startTransaction();
    
            if($camelo_1->update() == true)
            {
                $dao->commitTransaction();
    
                $this->result["result"] = true;
                $this->result["error"] = null;
            }
            else
            {
                if (!is_null($dao))
            {
                $dao->rollbackTransaction();
            }
            }
        }
        catch(\Exception $ex)
        {
            if (!is_null($dao))
            {
                $dao->rollbackTransaction();
            }
    
            $this->result["result"] = null;
            $this->result["error"] = $ex->getMessage();
        }
    
        print_r(json_encode($this->result));
    }
    
    public function delete_camelo_1($camelo_1Id)
    {
        $dao = null;
        try
        {
            $camelo_1 = new Camelo_1();
            $camelo_1->read($camelo_1Id);
    
            $dao = new DAO();
            $dao->startTransaction();
    
            if($camelo_1->delete() == true)
            {
                $dao->commitTransaction();
    
                $this->result["result"] = true;
                $this->result["error"] = null;
            }
            else
            {
                if (!is_null($dao))
            {
                $dao->rollbackTransaction();
            }

                $this->result["result"] = false;
                $this->result["error"] = "Could not delete Camelo_1!";
            }
        }
        catch(\Exception $ex)
        {
            if (!is_null($dao))
            {
                $dao->rollbackTransaction();
            }
    
            $this->result["result"] = null;
            $this->result["error"] = $ex->getMessage();
        }
    
        print_r(json_encode($this->result));
    }

    public function jacare_1s()
    {
        try
        {
            $jacare_1s = new Jacare_1s();
            $jacare_1s->read();
    
            $this->result["result"] = $jacare_1s->getList();
            $this->result["error"] = null;
        }
        catch(\Exception $ex)
        {
            $this->result["result"] = null;
            $this->result["error"] = $ex->getMessage();
        }
    
        print_r(json_encode($this->result));
    }
    
    public function jacare_1($jacare_1Id)
    {
        try
        {
            $jacare_1 = new Jacare_1();
            $jacare_1->setId($jacare_1Id);
            $jacare_1->read();
    
            $this->result["result"] = $jacare_1;
            $this->result["error"] = null;
        }
        catch(\Exception $ex)
        {
            $this->result["result"] = null;
            $this->result["error"] = $ex->getMessage();
        }
    
        print_r(json_encode($this->result));
    }
    
    public function add_jacare_1()
    {
        $dao = null;
        try
        {
            $jacare_1 = new Jacare_1();
            if(!is_null($_POST["dente_1"]) && isset($_POST["dente_1"]))
            {
                $jacare_1->setDente_1($_POST["dente_1"]);
            }
            $dao = new DAO();
            $dao->startTransaction();
    
            $jacare_1Id =$jacare_1->insert();

            if($jacare_1Id > 0)
            {
                $dao->commitTransaction();

                $this->result["result"] = $jacare_1Id;
                $this->result["error"] = null;
            }
            else
            {
                if (!is_null($dao))
            {
                $dao->rollbackTransaction();
            }
            }
        }
        catch(\Exception $ex)
        {
            if (!is_null($dao))
            {
                $dao->rollbackTransaction();
            }

            $this->result["result"] = null;
            $this->result["error"] = $ex->getMessage();
        }

        print_r(json_encode($this->result));
    }

    public function edit_jacare_1($jacare_1Id)
    {
        $dao = null;
        try
        {
            $jacare_1 = new Jacare_1();
            $jacare_1->read($jacare_1Id);
    
            if(!is_null($_POST["dente_1"]) && isset($_POST["dente_1"]))
            {
                $jacare_1->setDente_1($_POST["dente_1"]);
            }
            
            $dao = new DAO();
            $dao->startTransaction();
    
            if($jacare_1->update() == true)
            {
                $dao->commitTransaction();
    
                $this->result["result"] = true;
                $this->result["error"] = null;
            }
            else
            {
                if (!is_null($dao))
            {
                $dao->rollbackTransaction();
            }
            }
        }
        catch(\Exception $ex)
        {
            if (!is_null($dao))
            {
                $dao->rollbackTransaction();
            }
    
            $this->result["result"] = null;
            $this->result["error"] = $ex->getMessage();
        }
    
        print_r(json_encode($this->result));
    }
    
    public function delete_jacare_1($jacare_1Id)
    {
        $dao = null;
        try
        {
            $jacare_1 = new Jacare_1();
            $jacare_1->read($jacare_1Id);
    
            $dao = new DAO();
            $dao->startTransaction();
    
            if($jacare_1->delete() == true)
            {
                $dao->commitTransaction();
    
                $this->result["result"] = true;
                $this->result["error"] = null;
            }
            else
            {
                if (!is_null($dao))
            {
                $dao->rollbackTransaction();
            }

                $this->result["result"] = false;
                $this->result["error"] = "Could not delete Jacare_1!";
            }
        }
        catch(\Exception $ex)
        {
            if (!is_null($dao))
            {
                $dao->rollbackTransaction();
            }
    
            $this->result["result"] = null;
            $this->result["error"] = $ex->getMessage();
        }
    
        print_r(json_encode($this->result));
    }
}