import { deleteLobo_1, getLobo_1s } from './../api.js';

const tblLobo_1Id = "table-lobo-1"
const divContainerLobo_1sId = "container-lobo-1s";
const divNoLobo_1sId = "no-lobo-1s";
const btnRemoveClass = "remove-lobo-1";

function getRemoveButtonHTML() {
    const button = document.createElement("button");
    button.type = "button";
    button.classList.add("btn");
    button.classList.add("btn-danger");
    button.classList.add(btnRemoveClass);
    button.innerHTML = "Remover";

    return button
}

function getLobo_1sAndLoad() {
    getLobo_1s(
        function() {
            setLoading(true);
        }, function(lobo_1s) {
            if (lobo_1s.length > 0) {
                loadTable(lobo_1s);

                document.getElementById(divContainerLobo_1sId).classList.remove("d-none");
                document.getElementById(divNoLobo_1sId).classList.add("d-none");
            } else {
                document.getElementById(divContainerLobo_1sId).classList.add("d-none");
                document.getElementById(divNoLobo_1sId).classList.remove("d-none");
                showMessage("Algo deu errado!", 2);
            }
            setLoading(false);
        }, function(error) {
            document.getElementById(divContainerLobo_1sId).classList.add("d-none");
            document.getElementById(divNoLobo_1sId).classList.remove("d-none");
            showMessage("Algo deu errado!", 2);
            //console.error(error);
            setLoading(false);
        }
    )
}

function loadTable(lobo_1s) {
    lobo_1s.forEach((lobo_1) => {
        lobo_1.push(getRemoveButtonHTML())
    });

    $(`#${tblLobo_1Id}`).DataTable({
        data: lobo_1s, // TODO Deve estar assim: [ [ 1, "ModelA" ], [ 2, "ModelB" ] ]
        columns: [
            { title: "Id" },
            { title: "Nome" },
            { title: "#" }
        ],
        autoWidth: false,
        columnDefs: [{
            targets: ['_all'],
            className: 'mdc-data-table__cell'
        }]
    });
}

document.addEventListener(contentLoadedEventListener, function(event) {
    document.getElementById(divContainerLobo_1sId).classList.add("d-none");
    document.getElementById(divNoLobo_1sId).classList.remove("d-none");

    getLobo_1sAndLoad();

    document.getElementsByClassName(btnRemoveClass).forEach((btnRemove) => {
        btnRemove.onclick = function(evt) {
            const lobo_1Id = -1; // TODO Review (Pegar da coluna da tabela)

            Notiflix.Confirm.Show(
                'Atenção',
                'Tem certeza que deseja remover a/o Lobo_1?',
                'Sim',
                'Não',
                function() {
                    deleteLobo_1(
                        lobo_1Id,
                        function() {
                            setLoading(true);
                        },
                        function(result) {
                            if (result) {
                                showMessage("O/A Lobo_1 foi removido!", 1);
                                getLobo_1sAndLoad()
                            } else {
                                showMessage("Algo deu errado!", 2);
                                setLoading(false);
                            }
                        },
                        function(error) {
                            showMessage("Algo deu errado!", 2);
                            //console.error(error);
                            setLoading(false);
                        }
                    )
                },
                null
            );
        };
    });
});