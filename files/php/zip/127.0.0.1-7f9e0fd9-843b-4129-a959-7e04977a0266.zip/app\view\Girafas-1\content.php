<div class="row">
    <div class="col-12 col-sm-12 col-md-12 col-lg-12">
    <?php
        /*if (USEBREADCRUMB) {
            $breadcrumb = new Src\Classes\Breadcrumb();
            $breadcrumb->addBreadcrumb();
        }*/
    ?>
    </div>
</div>
<div class="row">
    <div class="col-12 col-sm-12 col-md-12 col-lg-12">
        <button type="button" class="btn btn-primary" data-mdb-toggle="modal" data-mdb-target="#mdl-add-edit-girafa-1">
            Adicionar
        </button>
    </div>
</div>
<div class="row mt-3">
    <div id="container-girafa-1s" class="col-12 col-sm-12 col-md-12 col-lg-12 d-none">
        <table id="table-girafa-1" class="table"></table>
    </div>
    <div id="no-girafa-1s" class="col-12 col-sm-12 col-md-12 col-lg-12">
        <label>Nenhum(a) Girafa-1s encontrado(a)!</label>
    </div>
</div>