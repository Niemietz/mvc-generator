import { addCachorro_1 } from './../api.js';

const frmCachorro_1Id = "form-cachorro-1";
const btnAddId = "add-cachorro-1";

function treatFormData(data) {
    data["raca_1"] = parseInt(data["raca_1"])
    return data
}

document.addEventListener(contentLoadedEventListener, function(event) {
    document.getElementById(btnAddId).onclick = function(evt) {
        const form = document.getElementById(frmCachorro_1Id);

        let data = form.serializeFormJSON();

        data = treatFormData(data);

        addCachorro_1(
            data,
            function() {
                setLoading(true);
            }, function(cachorro_1Id) {
                if (cachorro_1Id > 0) {
                    showMessage("O/A Cachorro_1 foi atualizado!", 1);
                } else {
                    showMessage("Algo deu errado!", 2);
                }
                setLoading(false);
            }, function(error) {
                showMessage("Algo deu errado!", 2);
                //console.error(error);
                setLoading(false);
            }
        )
    };
});