import { addLobo_1, editLobo_1, deleteLobo_1, getLobo_1, getLobo_1s } from './../api.js';

const lobo_1IdAttribute = "lobo-1Id"
const labLobo_1TitleId = "add-edit-lobo-1-title"
const mdlLobo_1Id = "mdl-add-edit-lobo-1"
const frmLobo_1Id = "form-lobo-1";
const divContainerLobo_1sId = "container-lobo-1s";
const divNoLobo_1sId = "no-lobo-1s";
const btnRemoveClass = "remove-lobo-1";
const btnAddEditId = "add-edit-lobo-1";
const inpMatilha_1Id = "matilha-1";

function getEditRemoveButtonHTML() {
    const editButton = document.createElement("button");
    editButton.type = "button";
    editButton.setAttribute("data-mdb-toggle", "modal")
    editButton.setAttribute("data-mdb-target", `#${mdlLobo_1Id}`)
    editButton.setAttribute("editing", "true")
    editButton.classList.add("btn");
    editButton.classList.add("btn-warning");
    editButton.innerHTML = "Atualizar";

    const removeButton = document.createElement("button");
    removeButton.type = "button";
    removeButton.classList.add("btn");
    removeButton.classList.add("btn-danger");
    removeButton.classList.add(btnRemoveClass);
    removeButton.innerHTML = "Remover";
    
    const divButtons = document.createElement("div");
    divButtons.append(editButton);
    divButtons.append(removeButton);

    return divButtons
}

function treatFormData(data) {

    
    return data
}

function getLobo_1sAndLoad() {
    getLobo_1s(
        function() {
            setLoading(true);
        }, function(lobo_1s) {
            if (lobo_1s.length > 0) {
                loadTable(lobo_1s);

                document.getElementById(divContainerLobo_1sId).classList.remove("d-none");
                document.getElementById(divNoLobo_1sId).classList.add("d-none");
            } else {
                document.getElementById(divContainerLobo_1sId).classList.add("d-none");
                document.getElementById(divNoLobo_1sId).classList.remove("d-none");
                showMessage("Algo deu errado!", 2);
            }
            setLoading(false);
        }, function(error) {
            document.getElementById(divContainerLobo_1sId).classList.add("d-none");
            document.getElementById(divNoLobo_1sId).classList.remove("d-none");
            showMessage("Algo deu errado!", 2);
            //console.error(error);
            setLoading(false);
        }
    )
}

function loadTable(lobo_1s) {
    lobo_1s.forEach((lobo_1) => {
        lobo_1.push(getEditRemoveButtonHTML())
    });

    $(`#${tblLobo_1Id}`).DataTable({
        data: lobo_1s, // TODO Deve estar assim: [ [ 1, "ModelA" ], [ 2, "ModelB" ] ]
        columns: [
            { title: "Id" },
            { title: "Nome" },
            { title: "#" }
        ],
        autoWidth: false,
        columnDefs: [{
            targets: ['_all'],
            className: 'mdc-data-table__cell'
        }]
    });
}

document.addEventListener(contentLoadedEventListener, function(event) {
    document.getElementById(divContainerLobo_1sId).classList.add("d-none");
    document.getElementById(divNoLobo_1sId).classList.remove("d-none");

    const modalEl = document.getElementById(mdlLobo_1Id);
    const modal = new mdb.Modal(modalEl);

    getLobo_1sAndLoad();

    modalEl.addEventListener('show.mdb.modal', (event) => {
        /*if (event.target.related.getAttribute("editing") == "true") {   // TODO Review
            const lobo_1Id = -1; // TODO Review (Pegar da coluna da tabela)
            document.getElementById(btnAddEditId).setAttribute(lobo_1IdAttribute, lobo_1Id)
            document.getElementById(btnAddEditId).innerHTML = "Atualizar"
            document.getElementById(labLobo_1TitleId).innerHTML = "Atualizar Lobo-1"
            
            getLobo_1(lobo_1Id,
                function() {
                    setLoading(true);
                    //setLoadingModal(true, document.getElementById(mdlLobo_1Id)); // TODO Review
                },
                function(lobo_1) {

                    document.getElementById(inpMatilha_1Id).value = lobo_1.matilha_1

                    //setLoadingModal(false, document.getElementById(mdlLobo_1Id)); // TODO Review
                    setLoading(false);
                },
                function(error) {
                    //setLoadingModal(false, document.getElementById(mdlLobo_1Id)); // TODO Review
                    modal.hide();
                    showMessage("Algo deu errado!", 2);
                    //console.error(error);
                    setLoading(false);
                }
            )
        } else {*/
            document.getElementById(btnAddEditId).removeAttribute(lobo_1IdAttribute)
            document.getElementById(btnAddEditId).innerHTML = "Adicionar"
            document.getElementById(labLobo_1TitleId).innerHTML = "Adicionar Lobo-1"
        //}
    });

    document.getElementsByClassName(btnRemoveClass).forEach((btnRemove) => {
        btnRemove.onclick = function(evt) {
            const lobo_1Id = -1; // TODO Review (Pegar da coluna da tabela)

            Notiflix.Confirm.Show(
                'Atenção',
                'Tem certeza que deseja remover a/o Lobo_1?',
                'Sim',
                'Não',
                function() {
                    deleteLobo_1(
                        lobo_1Id,
                        function() {
                            setLoading(true);
                        },
                        function(result) {
                            if (result) {
                                showMessage("O/A Lobo_1 foi removido!", 1);
                                getLobo_1sAndLoad()
                            } else {
                                showMessage("Algo deu errado!", 2);
                                setLoading(false);
                            }
                        },
                        function(error) {
                            showMessage("Algo deu errado!", 2);
                            //console.error(error);
                            setLoading(false);
                        }
                    )
                },
                null
            );
        };
    });

    document.getElementById(btnAddEditId).onclick = function(evt) {
        let lobo_1Id = -1
        if (this.hasAttribute(lobo_1IdAttribute)) {
            lobo_1Id = parseInt(this.getAttribute(lobo_1IdAttribute))
        }

        const form = document.getElementById(frmLobo_1Id);

        let data = form.serializeFormJSON();

        data = treatFormData(data);

        if (lobo_1Id > -1) {
            editLobo_1(
                lobo_1Id,
                data,
                function() {
                    setLoading(true);
                    //setLoadingModal(true, document.getElementById(mdlLobo_1Id)); // TODO Review
                }, function(result) {
                    //setLoadingModal(false, document.getElementById(mdlLobo_1Id)); // TODO Review
                    modal.hide();
                    if (result) {
                        getLobo_1sAndLoad()
                        showMessage("O/A Lobo_1 foi atualizado!", 1);
                    } else {
                        showMessage("Algo deu errado!", 2);
                    }
                    setLoading(false);
                }, function(error) {
                    //setLoadingModal(false, document.getElementById(mdlLobo_1Id)); // TODO Review
                    modal.hide();
                    showMessage("Algo deu errado!", 2);
                    //console.error(error);
                    setLoading(false);
                }
            )
        } else {
            addLobo_1(
                data,
                function() {
                    setLoading(true);
                    //setLoadingModal(true, document.getElementById(mdlLobo_1Id)); // TODO Review
                }, function(lobo_1Id) {
                    //setLoadingModal(false, document.getElementById(mdlLobo_1Id)); // TODO Review
                    modal.hide();
                    if (lobo_1Id > 0) {
                        getLobo_1sAndLoad();
                        showMessage("O/A Lobo_1 foi atualizado!", 1);
                    } else {
                        showMessage("Algo deu errado!", 2);
                    }
                    setLoading(false);
                }, function(error) {
                    //setLoadingModal(false, document.getElementById(mdlLobo_1Id)); // TODO Review
                    modal.hide();
                    showMessage("Algo deu errado!", 2);
                    //console.error(error);
                    setLoading(false);
                }
            )
        }
    };
});