import { addGirafa_1, editGirafa_1, getGirafa_1, getGirafa_1s } from './../api.js';

const girafa_1IdAttribute = "girafa-1Id"
const labGirafa_1TitleId = "add-edit-girafa-1-title"
const mdlGirafa_1Id = "mdl-add-edit-girafa-1"
const frmGirafa_1Id = "form-girafa-1";
const divContainerGirafa_1sId = "container-girafa-1s";
const divNoGirafa_1sId = "no-girafa-1s";
const btnAddEditId = "add-edit-girafa-1";
const inpAmazonense_1Id = "amazonense-1";

function getEditButtonHTML() {
    const button = document.createElement("button");
    button.type = "button";
    button.setAttribute("data-mdb-toggle", "modal")
    button.setAttribute("data-mdb-target", `#${mdlGirafa_1Id}`)
    button.setAttribute("editing", "true")
    button.classList.add("btn");
    button.classList.add("btn-warning");
    button.innerHTML = "Atualizar";

    return button
}

function treatFormData(data) {

    data["amazonense_1"] = parseFloat(data["amazonense_1"])
    
    return data
}

function getGirafa_1sAndLoad() {
    getGirafa_1s(
        function() {
            setLoading(true);
        }, function(girafa_1s) {
            if (girafa_1s.length > 0) {
                loadTable(girafa_1s);

                document.getElementById(divContainerGirafa_1sId).classList.remove("d-none");
                document.getElementById(divNoGirafa_1sId).classList.add("d-none");
            } else {
                document.getElementById(divContainerGirafa_1sId).classList.add("d-none");
                document.getElementById(divNoGirafa_1sId).classList.remove("d-none");
                showMessage("Algo deu errado!", 2);
            }
            setLoading(false);
        }, function(error) {
            document.getElementById(divContainerGirafa_1sId).classList.add("d-none");
            document.getElementById(divNoGirafa_1sId).classList.remove("d-none");
            showMessage("Algo deu errado!", 2);
            //console.error(error);
            setLoading(false);
        }
    )
}

function loadTable(girafa_1s) {
    girafa_1s.forEach((girafa_1) => {
        girafa_1.push(getEditButtonHTML())
    });

    $(`#${tblGirafa_1Id}`).DataTable({
        data: girafa_1s, // TODO Deve estar assim: [ [ 1, "ModelA" ], [ 2, "ModelB" ] ]
        columns: [
            { title: "Id" },
            { title: "Nome" },
            { title: "#" }
        ],
        autoWidth: false,
        columnDefs: [{
            targets: ['_all'],
            className: 'mdc-data-table__cell'
        }]
    });
}

document.addEventListener(contentLoadedEventListener, function(event) {
    document.getElementById(divContainerGirafa_1sId).classList.add("d-none");
    document.getElementById(divNoGirafa_1sId).classList.remove("d-none");

    const modalEl = document.getElementById(mdlGirafa_1Id);
    const modal = new mdb.Modal(modalEl);

    getGirafa_1sAndLoad();

    modalEl.addEventListener('show.mdb.modal', (event) => {
        /*if (event.target.related.getAttribute("editing") == "true") {   // TODO Review
            const girafa_1Id = -1; // TODO Review (Pegar da coluna da tabela)
            document.getElementById(btnAddEditId).setAttribute(girafa_1IdAttribute, girafa_1Id)
            document.getElementById(btnAddEditId).innerHTML = "Atualizar"
            document.getElementById(labGirafa_1TitleId).innerHTML = "Atualizar Girafa-1"

            getGirafa_1(girafa_1Id,
                function() {
                    setLoading(true);
                    //setLoadingModal(true, document.getElementById(mdlGirafa_1Id)); // TODO Review
                },
                function(girafa_1) {
    
                    document.getElementById(inpAmazonense_1Id).value = girafa_1.amazonense_1
    
                    //setLoadingModal(false, document.getElementById(mdlGirafa_1Id)); // TODO Review
                    setLoading(false);
                },
                function(error) {
                    //setLoadingModal(false, document.getElementById(mdlGirafa_1Id)); // TODO Review
                    modal.hide();
                    showMessage("Algo deu errado!", 2);
                    //console.error(error);
                    setLoading(false);
                }
            )
        } else {*/
            document.getElementById(btnAddEditId).removeAttribute(girafa_1IdAttribute)
            document.getElementById(btnAddEditId).innerHTML = "Adicionar"
            document.getElementById(labGirafa_1TitleId).innerHTML = "Adicionar Girafa-1"
        //}
    });

    document.getElementById(btnAddEditId).onclick = function(evt) {
        let girafa_1Id = -1
        if (this.hasAttribute(girafa_1IdAttribute)) {
            girafa_1Id = parseInt(this.getAttribute(girafa_1IdAttribute))
        }

        const form = document.getElementById(frmGirafa_1Id);

        let data = form.serializeFormJSON();

        data = treatFormData(data);

        if (girafa_1Id > -1) {
            editGirafa_1(
                girafa_1Id,
                data,
                function() {
                    setLoading(true);
                    //setLoadingModal(true, document.getElementById(mdlGirafa_1Id)); // TODO Review
                }, function(result) {
                    //setLoadingModal(false, document.getElementById(mdlGirafa_1Id)); // TODO Review
                    modal.hide();
                    if (result) {
                        getGirafa_1sAndLoad()
                        showMessage("O/A Girafa_1 foi atualizado!", 1);
                    } else {
                        showMessage("Algo deu errado!", 2);
                    }
                    setLoading(false);
                }, function(error) {
                    //setLoadingModal(false, document.getElementById(mdlGirafa_1Id)); // TODO Review
                    modal.hide();
                    showMessage("Algo deu errado!", 2);
                    //console.error(error);
                    setLoading(false);
                }
            )
        } else {
            addGirafa_1(
                data,
                function() {
                    setLoading(true);
                    //setLoadingModal(true, document.getElementById(mdlGirafa_1Id)); // TODO Review
                }, function(girafa_1Id) {
                    //setLoadingModal(false, document.getElementById(mdlGirafa_1Id)); // TODO Review
                    modal.hide();
                    if (girafa_1Id > 0) {
                        getGirafa_1sAndLoad();
                        showMessage("O/A Girafa_1 foi atualizado!", 1);
                    } else {
                        showMessage("Algo deu errado!", 2);
                    }
                    setLoading(false);
                }, function(error) {
                    //setLoadingModal(false, document.getElementById(mdlGirafa_1Id)); // TODO Review
                    modal.hide();
                    showMessage("Algo deu errado!", 2);
                    //console.error(error);
                    setLoading(false);
                }
            )
        }
    };
});