<?php
namespace App\Model;

use App\Model\SuperClass\eModel;

use App\Data\DAO;

class Cachorro_1 extends eModel
{
    private $raca_1;
    
    function __construct()
    {
        parent::__construct();
        $this->raca_1 = -1;
    }

    public function read()
    {
        $result = false;

        $query = "SELECT ";
        $query .= "c.raca-1";
        $query .= " FROM cachorros-1 c";
        $query .= " WHERE c.id = " . $this->getId();

        $dao = new DAO();
        $sql = $dao->executeQuery($query);

        if(mysqli_num_rows($sql) > 0)
        {
            if($row = $sql->fetch_assoc())
            {
                $this->setId($row['id']);
                $this->setRaca_1($row['raca-1']);
            }

            $result = true;
        }

        return $result;
    }

    public function insert()
    {
        $result = 0;

        $query = "SELECT c.id";
        $query .= " FROM cachorros-1 c";
        $query .= " WHERE c.raca-1 = " . $this->getRaca_1();
        
        $dao = new DAO();
        $sql = $dao->executeQuery($query);

        if(mysqli_num_rows($sql) == 0)
        {
            $query = "INSERT INTO cachorros-1(";
            $query .= "raca-1";
            $query .= ")";
            $query .= " VALUES (";
            $query .= $this->getRaca_1();
            $query .= ")";

            $cachorro_1Id = $dao->executeQueryAndGetId($query);

            if($cachorro_1Id > 0)
            {
                $this->setId($cachorro_1Id);
                $result = $cachorro_1Id;
            }
        }
        else
        {
            if($row = $sql->fetch_assoc())
            {
                $this->setId((int)$row["id"]);
                $result = (int)$row["id"];
            }
        }

        return $result;
    }

    public function update()
    {
        $result = false;

        if($this->getId() > 0)
        {
            $query = "UPDATE cachorros-1 SET ";
            $query .= "raca-1 = " . $this->getRaca_1();
            $query .= " WHERE id = " . $this->getId();

            $dao = new DAO();
            if($dao->executeQueryAndGetNumberOfAffectedRows($query) > 0)
            {
                $result = true;
            }
        }

        return $result;
    }

    public function delete()
    {
        $result = false;

        if($this->getId() > 0)
        {
            $query = "DELETE FROM cachorros-1";
            $query .= " WHERE id = " . $this->getId();

            try
            {
                $dao = new DAO();
                if($dao->executeQueryAndGetNumberOfAffectedRows($query))
                {
                    $result = true;
                }
            }
            catch(Exception $error)
            {
                throw $error;
            }
        }
        else
        {
            throw new \Exception("Could not delete Cachorro_1 from database: Missing ID.");
        }

        return $result;
    }

    public function getRaca_1()
    {
        return $this->raca_1;
    }

    public function setRaca_1($raca_1)
    {
        $this->raca_1 = $raca_1;
    }

    public function jsonSerialize()
    {
        return array(
            'id' => $this->getId(),
            'raca_1' => $this->getRaca_1()
        );
    }
}