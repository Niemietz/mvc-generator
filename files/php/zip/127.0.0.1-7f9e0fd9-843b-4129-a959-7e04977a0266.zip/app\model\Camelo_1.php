<?php
namespace App\Model;

use App\Model\SuperClass\eModel;

use App\Data\DAO;

class Camelo_1 extends eModel
{
    private $corcova_1;
    
    function __construct()
    {
        parent::__construct();
        $this->corcova_1 = -1;
    }

    public function read()
    {
        $result = false;

        $query = "SELECT ";
        $query .= "c.corcova-1";
        $query .= " FROM camelos-1 c";
        $query .= " WHERE c.id = " . $this->getId();

        $dao = new DAO();
        $sql = $dao->executeQuery($query);

        if(mysqli_num_rows($sql) > 0)
        {
            if($row = $sql->fetch_assoc())
            {
                $this->setId($row['id']);
                $this->setCorcova_1($row['corcova-1']);
            }

            $result = true;
        }

        return $result;
    }

    public function insert()
    {
        $result = 0;

        $query = "SELECT c.id";
        $query .= " FROM camelos-1 c";
        $query .= " WHERE c.corcova-1 = " . $this->getCorcova_1();
        
        $dao = new DAO();
        $sql = $dao->executeQuery($query);

        if(mysqli_num_rows($sql) == 0)
        {
            $query = "INSERT INTO camelos-1(";
            $query .= "corcova-1";
            $query .= ")";
            $query .= " VALUES (";
            $query .= $this->getCorcova_1();
            $query .= ")";

            $camelo_1Id = $dao->executeQueryAndGetId($query);

            if($camelo_1Id > 0)
            {
                $this->setId($camelo_1Id);
                $result = $camelo_1Id;
            }
        }
        else
        {
            if($row = $sql->fetch_assoc())
            {
                $this->setId((int)$row["id"]);
                $result = (int)$row["id"];
            }
        }

        return $result;
    }

    public function update()
    {
        $result = false;

        if($this->getId() > 0)
        {
            $query = "UPDATE camelos-1 SET ";
            $query .= "corcova-1 = " . $this->getCorcova_1();
            $query .= " WHERE id = " . $this->getId();

            $dao = new DAO();
            if($dao->executeQueryAndGetNumberOfAffectedRows($query) > 0)
            {
                $result = true;
            }
        }

        return $result;
    }

    public function delete()
    {
        $result = false;

        if($this->getId() > 0)
        {
            $query = "DELETE FROM camelos-1";
            $query .= " WHERE id = " . $this->getId();

            try
            {
                $dao = new DAO();
                if($dao->executeQueryAndGetNumberOfAffectedRows($query))
                {
                    $result = true;
                }
            }
            catch(Exception $error)
            {
                throw $error;
            }
        }
        else
        {
            throw new \Exception("Could not delete Camelo_1 from database: Missing ID.");
        }

        return $result;
    }

    public function getCorcova_1()
    {
        return $this->corcova_1;
    }

    public function setCorcova_1($corcova_1)
    {
        $this->corcova_1 = $corcova_1;
    }

    public function jsonSerialize()
    {
        return array(
            'id' => $this->getId(),
            'corcova_1' => $this->getCorcova_1()
        );
    }
}