<div class="row">
    <div class="col-12 col-sm-12 col-md-12 col-lg-12">
    <?php
        /*if (USEBREADCRUMB) {
            $breadcrumb = new Src\Classes\Breadcrumb();
            $breadcrumb->addBreadcrumb();
        }*/
    ?>
    </div>
</div>
<form id="form-cachorro-1">
    <div class="row">        <div class="col-12 col-sm-4 col-md-4 col-lg-4">
            <div class="form-outline">
                <input name="raca_1" type="number" id="raca-1" class="form-control" />
                <label class="form-label" for="raca-1">Raca-1</label>
            </div>
        </div>    </div></form>
<div class="row mt-3">
    <div class="col-12 col-sm-12 col-md-12 col-lg-12">
        <button id="add-cachorro-1" type="button" class="btn btn-success">Adicionar</button>
    </div>
</div>