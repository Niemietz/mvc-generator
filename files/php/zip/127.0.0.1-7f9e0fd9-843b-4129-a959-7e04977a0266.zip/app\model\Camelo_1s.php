<?php
namespace App\Model;

use App\Model\SuperClass\eModelList;
use App\Model\Camelo_1;
use App\Data\DAO;

class Camelo_1s extends eModelList
{
    public function read()
    {
        $result = false;

        $query = "SELECT c.id, ";
        $query .= "c.corcova-1";
        $query .= " FROM camelos-1 c";

        try
        {
            $dao = new DAO();
            $sql = $dao->executeQuery($query);

            if(mysqli_num_rows($sql) > 0)
            {
                while($row = $sql->fetch_array())
                {
                    $camelo_1 = new Camelo_1();
                    $camelo_1->setId($row['id']);
                    $camelo_1->setCorcova_1($row['corcova-1']);

                    $this->add($camelo_1);
                }

                $result = true;
            }
        }
        catch(\Exception $error)
        {
            throw $error;
        }

        return $result;
    }
}