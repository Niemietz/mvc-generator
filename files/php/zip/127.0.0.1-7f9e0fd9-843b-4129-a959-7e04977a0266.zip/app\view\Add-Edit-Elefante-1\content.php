<div class="row">
    <div class="col-12 col-sm-12 col-md-12 col-lg-12">
    <?php
        /*if (USEBREADCRUMB) {
            $breadcrumb = new Src\Classes\Breadcrumb();
            $breadcrumb->addBreadcrumb();
        }*/
    ?>
    </div>
</div>
<form id="form-elefante-1">
    <div class="row">        <div class="col-12 col-sm-4 col-md-4 col-lg-4">
            <div class="form-outline">
                <input name="tamanho_1" type="text" id="tamanho-1" class="form-control"
<?php
if (isset($_GET["id"]) && !is_null($_GET["id"]) && $_GET["id"] > -1) {
?>
    value="
<?= (isset($_GET["id"]) && isset($_POST["tamanho_1"]) && !is_null($_GET["id"]) && !is_null($_POST["tamanho_1"]) && $_GET["id"] > -1) ? $_POST["tamanho_1"] : "" ?>
"
<?php
}
?>
                />
                <label class="form-label" for="tamanho-1">Tamanho-1</label>
            </div>
        </div>    </div>
</form>
<div class="row mt-3">
    <div class="col-12 col-sm-12 col-md-12 col-lg-12">
        <button id="edit-elefante-1" type="button" class="btn btn-warning
<?php
if (!isset($_GET["id"]) || is_null($_GET["id"]) || $_GET["id"] <= -1) {
    echo "d-none";
}
?>
" elefante-1Id="<?= (isset($_GET["id"]) && !is_null($_GET["id"]) && $_GET["id"] > -1) ? $_GET["id"] : "-1" ?>">Atualizar</button>

        <button id="add-elefante-1" type="button" class="btn btn-success
<?php
if (isset($_GET["id"]) && !is_null($_GET["id"]) && $_GET["id"] > -1) {
    echo "d-none";
}
?>
">Adicionar</button>
    </div>
</div>