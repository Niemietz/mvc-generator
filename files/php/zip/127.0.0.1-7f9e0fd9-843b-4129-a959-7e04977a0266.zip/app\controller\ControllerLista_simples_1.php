<?php

namespace App\Controller;
    
use Src\Classes\Render;
    
class ControllerLista_Simples_1 extends Render
{
    public function __construct()
    {
        parent::__construct();

        $this->setTitle("Pág. de Lista");
        $this->setDescription("");
        $this->setKeywords(array(
        ));
        $this->setDirectory("Lista-Simples-1");

        $this->renderLayout();
    }
}
