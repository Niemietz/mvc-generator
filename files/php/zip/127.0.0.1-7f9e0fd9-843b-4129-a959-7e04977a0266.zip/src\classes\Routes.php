<?php
namespace Src\Classes;

use Src\Traits\UrlParser;

class Routes
{
    use UrlParser;
    
    private $route;

    public function getRoute()
    {
        $url = $this->parseUrl();
        $I = $url[0];

        $this->route = array(
            "" => "ControllerHome",
            "home" => "ControllerHome",
            "sitemap" => "ControllerSitemap",
"teste-1" => "ControllerTeste_1",
"add_cachorro-1" => "ControllerAdd_Cachorro_1",
"add-edit-elefante-1" => "ControllerAdd_Edit_Elefante_1",
"lista-simples-1" => "ControllerLista_Simples_1",
"gatos-1" => "ControllerGatos_1",
"ratos-1" => "ControllerRatos_1",
"lobos-1" => "ControllerLobos_1",
"girafas-1" => "ControllerGirafas_1",
"camelos-1" => "ControllerCamelos_1",
"jacares-1" => "ControllerJacares_1",
"lobos-completos-1" => "ControllerLobos_Completos_1",

            // JSON
            "api" => "ControllerAPI"
        );

        if(array_key_exists($I, $this->route))
        {
            if(file_exists(DIRREQ . "app/controller/{$this->route[$I]}.php"))
            {
                session_start();
                return $this->route[$I];
            }
            else
            {
                return "ControllerHome";
            }
        }
        else
        {
            return "Controller404";
        }
    }
}