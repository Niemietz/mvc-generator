<?php

namespace App\Controller;
    
use Src\Classes\Render;
    
class ControllerLobos_1 extends Render
{
    public function __construct()
    {
        parent::__construct();

        $this->setTitle("Lobos-1");
        $this->setDescription("");
        $this->setKeywords(array(
        ));
        $this->setDirectory("Lobos-1");

        $this->renderLayout();
    }
}
