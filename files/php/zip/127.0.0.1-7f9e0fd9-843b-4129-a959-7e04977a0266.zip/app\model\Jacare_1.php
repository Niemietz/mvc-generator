<?php
namespace App\Model;

use App\Model\SuperClass\eModel;

use App\Data\DAO;

class Jacare_1 extends eModel
{
    private $dente_1;
    
    function __construct()
    {
        parent::__construct();
        $this->dente_1 = -1;
    }

    public function read()
    {
        $result = false;

        $query = "SELECT ";
        $query .= "j.dente-1";
        $query .= " FROM jacares-1 j";
        $query .= " WHERE j.id = " . $this->getId();

        $dao = new DAO();
        $sql = $dao->executeQuery($query);

        if(mysqli_num_rows($sql) > 0)
        {
            if($row = $sql->fetch_assoc())
            {
                $this->setId($row['id']);
                $this->setDente_1($row['dente-1']);
            }

            $result = true;
        }

        return $result;
    }

    public function insert()
    {
        $result = 0;

        $query = "SELECT j.id";
        $query .= " FROM jacares-1 j";
        $query .= " WHERE j.dente-1 = " . $this->getDente_1();
        
        $dao = new DAO();
        $sql = $dao->executeQuery($query);

        if(mysqli_num_rows($sql) == 0)
        {
            $query = "INSERT INTO jacares-1(";
            $query .= "dente-1";
            $query .= ")";
            $query .= " VALUES (";
            $query .= $this->getDente_1();
            $query .= ")";

            $jacare_1Id = $dao->executeQueryAndGetId($query);

            if($jacare_1Id > 0)
            {
                $this->setId($jacare_1Id);
                $result = $jacare_1Id;
            }
        }
        else
        {
            if($row = $sql->fetch_assoc())
            {
                $this->setId((int)$row["id"]);
                $result = (int)$row["id"];
            }
        }

        return $result;
    }

    public function update()
    {
        $result = false;

        if($this->getId() > 0)
        {
            $query = "UPDATE jacares-1 SET ";
            $query .= "dente-1 = " . $this->getDente_1();
            $query .= " WHERE id = " . $this->getId();

            $dao = new DAO();
            if($dao->executeQueryAndGetNumberOfAffectedRows($query) > 0)
            {
                $result = true;
            }
        }

        return $result;
    }

    public function delete()
    {
        $result = false;

        if($this->getId() > 0)
        {
            $query = "DELETE FROM jacares-1";
            $query .= " WHERE id = " . $this->getId();

            try
            {
                $dao = new DAO();
                if($dao->executeQueryAndGetNumberOfAffectedRows($query))
                {
                    $result = true;
                }
            }
            catch(Exception $error)
            {
                throw $error;
            }
        }
        else
        {
            throw new \Exception("Could not delete Jacare_1 from database: Missing ID.");
        }

        return $result;
    }

    public function getDente_1()
    {
        return $this->dente_1;
    }

    public function setDente_1($dente_1)
    {
        $this->dente_1 = $dente_1;
    }

    public function jsonSerialize()
    {
        return array(
            'id' => $this->getId(),
            'dente_1' => $this->getDente_1()
        );
    }
}