<?php

namespace App\Controller;
    
use Src\Classes\Render;
    
class ControllerGatos_1 extends Render
{
    public function __construct()
    {
        parent::__construct();

        $this->setTitle("Gatos-1");
        $this->setDescription("");
        $this->setKeywords(array(
        ));
        $this->setDirectory("Gatos-1");

        $this->renderLayout();
    }
}
