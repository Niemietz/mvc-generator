import { addJacare_1, deleteJacare_1, getJacare_1s } from './../api.js';

const tblJacare_1Id = "table-jacare-1"
const mdlJacare_1Id = "mdl-add-jacare-1"
const frmJacare_1Id = "form-jacare-1";
const divContainerJacare_1sId = "container-jacare-1s";
const divNoJacare_1sId = "no-jacare-1s";
const btnRemoveClass = "remove-jacare-1";
const btnAddId = "add-jacare-1";

function getRemoveButtonHTML() {
    const button = document.createElement("button");
    button.type = "button";
    button.classList.add("btn");
    button.classList.add("btn-danger");
    button.classList.add(btnRemoveClass);
    button.innerHTML = "Remover";

    return button
}

function getJacare_1sAndLoad() {
    getJacare_1s(
        function() {
            setLoading(true);
        }, function(jacare_1s) {
            if (jacare_1s.length > 0) {
                loadTable(jacare_1s);

                document.getElementById(divContainerJacare_1sId).classList.remove("d-none");
                document.getElementById(divNoJacare_1sId).classList.add("d-none");
            } else {
                document.getElementById(divContainerJacare_1sId).classList.add("d-none");
                document.getElementById(divNoJacare_1sId).classList.remove("d-none");
                showMessage("Algo deu errado!", 2);
            }
            setLoading(false);
        }, function(error) {
            document.getElementById(divContainerJacare_1sId).classList.add("d-none");
            document.getElementById(divNoJacare_1sId).classList.remove("d-none");
            showMessage("Algo deu errado!", 2);
            //console.error(error);
            setLoading(false);
        }
    )
}

function treatFormData(data) {

    data["dente_1"] = parseInt(data["dente_1"])
    
    return data
}

function loadTable(jacare_1s) {
    jacare_1s.forEach((jacare_1) => {
        jacare_1.push(getRemoveButtonHTML())
    });

    $(`#${tblJacare_1Id}`).DataTable({
        data: jacare_1s, // TODO Deve estar assim: [ [ 1, "ModelA" ], [ 2, "ModelB" ] ]
        columns: [
            { title: "Id" },
            { title: "Nome" },
            { title: "#" }
        ],
        autoWidth: false,
        columnDefs: [{
            targets: ['_all'],
            className: 'mdc-data-table__cell'
        }]
    });
}

document.addEventListener(contentLoadedEventListener, function(event) {
    document.getElementById(divContainerJacare_1sId).classList.add("d-none");
    document.getElementById(divNoJacare_1sId).classList.remove("d-none");

    const modalEl = document.getElementById(mdlJacare_1Id);
    const modal = new mdb.Modal(modalEl);

    getJacare_1sAndLoad();

    document.getElementsByClassName(btnRemoveClass).forEach((btnRemove) => {
        btnRemove.onclick = function(evt) {
            const jacare_1Id = -1; // TODO Review (Pegar da coluna da tabela)

            Notiflix.Confirm.Show(
                'Atenção',
                'Tem certeza que deseja remover a/o Jacare_1?',
                'Sim',
                'Não',
                function() {
                    deleteJacare_1(
                        jacare_1Id,
                        function() {
                            setLoading(true);
                        },
                        function(result) {
                            if (result) {
                                showMessage("O/A Jacare_1 foi removido!", 1);
                                getJacare_1sAndLoad()
                            } else {
                                showMessage("Algo deu errado!", 2);
                                setLoading(false);
                            }
                        },
                        function(error) {
                            showMessage("Algo deu errado!", 2);
                            //console.error(error);
                            setLoading(false);
                        }
                    )
                },
                null
            );
        };
    });

    document.getElementById(btnAddId).onclick = function(evt) {
        const form = document.getElementById(frmJacare_1Id);

        let data = form.serializeFormJSON();

        data = treatFormData(data);

        addJacare_1(
            data,
            function() {
                setLoading(true);
                //setLoadingModal(true, document.getElementById(mdlJacare_1Id)); // TODO Review
            }, function(result) {
                //setLoadingModal(false, document.getElementById(mdlJacare_1Id)); // TODO Review
                modal.hide();
                if (result) {
                    showMessage("O/A Jacare_1 foi atualizado!", 1);
                    getJacare_1sAndLoad()
                } else {
                    showMessage("Algo deu errado!", 2);
                    setLoading(false);
                }
            }, function(error) {
                //setLoadingModal(false, document.getElementById(mdlJacare_1Id)); // TODO Review
                modal.hide();
                showMessage("Algo deu errado!", 2);
                //console.error(error);
                setLoading(false);
            }
        )
    };
});