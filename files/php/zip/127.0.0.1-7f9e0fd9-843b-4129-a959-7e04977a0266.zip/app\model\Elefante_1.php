<?php
namespace App\Model;

use App\Model\SuperClass\eModel;

use App\Data\DAO;

class Elefante_1 extends eModel
{
    private $tamanho_1;
    
    function __construct()
    {
        parent::__construct();
        $this->tamanho_1 = -1;
    }

    public function read()
    {
        $result = false;

        $query = "SELECT ";
        $query .= "e.tamanho-1";
        $query .= " FROM elefantes-1 e";
        $query .= " WHERE e.id = " . $this->getId();

        $dao = new DAO();
        $sql = $dao->executeQuery($query);

        if(mysqli_num_rows($sql) > 0)
        {
            if($row = $sql->fetch_assoc())
            {
                $this->setId($row['id']);
                $this->setTamanho_1($row['tamanho-1']);
            }

            $result = true;
        }

        return $result;
    }

    public function insert()
    {
        $result = 0;

        $query = "SELECT e.id";
        $query .= " FROM elefantes-1 e";
        $query .= " WHERE e.tamanho-1 = " . $this->getTamanho_1();
        
        $dao = new DAO();
        $sql = $dao->executeQuery($query);

        if(mysqli_num_rows($sql) == 0)
        {
            $query = "INSERT INTO elefantes-1(";
            $query .= "tamanho-1";
            $query .= ")";
            $query .= " VALUES (";
            $query .= $this->getTamanho_1();
            $query .= ")";

            $elefante_1Id = $dao->executeQueryAndGetId($query);

            if($elefante_1Id > 0)
            {
                $this->setId($elefante_1Id);
                $result = $elefante_1Id;
            }
        }
        else
        {
            if($row = $sql->fetch_assoc())
            {
                $this->setId((int)$row["id"]);
                $result = (int)$row["id"];
            }
        }

        return $result;
    }

    public function update()
    {
        $result = false;

        if($this->getId() > 0)
        {
            $query = "UPDATE elefantes-1 SET ";
            $query .= "tamanho-1 = " . $this->getTamanho_1();
            $query .= " WHERE id = " . $this->getId();

            $dao = new DAO();
            if($dao->executeQueryAndGetNumberOfAffectedRows($query) > 0)
            {
                $result = true;
            }
        }

        return $result;
    }

    public function delete()
    {
        $result = false;

        if($this->getId() > 0)
        {
            $query = "DELETE FROM elefantes-1";
            $query .= " WHERE id = " . $this->getId();

            try
            {
                $dao = new DAO();
                if($dao->executeQueryAndGetNumberOfAffectedRows($query))
                {
                    $result = true;
                }
            }
            catch(Exception $error)
            {
                throw $error;
            }
        }
        else
        {
            throw new \Exception("Could not delete Elefante_1 from database: Missing ID.");
        }

        return $result;
    }

    public function getTamanho_1()
    {
        return $this->tamanho_1;
    }

    public function setTamanho_1($tamanho_1)
    {
        $this->tamanho_1 = $tamanho_1;
    }

    public function jsonSerialize()
    {
        return array(
            'id' => $this->getId(),
            'tamanho_1' => $this->getTamanho_1()
        );
    }
}