import { addGato_1, getGato_1s } from './../api.js';

const tblGato_1Id = "table-gato-1"
const mdlGato_1Id = "mdl-add-gato-1"
const frmGato_1Id = "form-gato-1";
const divContainerGato_1sId = "container-gato-1s";
const divNoGato_1sId = "no-gato-1s";
const btnAddId = "add-gato-1";

function getGato_1sAndLoad() {
    getGato_1s(
        function() {
            setLoading(true);
        }, function(gato_1s) {
            if (gato_1s.length > 0) {
                loadTable(gato_1s);

                document.getElementById(divContainerGato_1sId).classList.remove("d-none");
                document.getElementById(divNoGato_1sId).classList.add("d-none");
            } else {
                document.getElementById(divContainerGato_1sId).classList.add("d-none");
                document.getElementById(divNoGato_1sId).classList.remove("d-none");
                showMessage("Algo deu errado!", 2);
            }
            setLoading(false);
        }, function(error) {
            document.getElementById(divContainerGato_1sId).classList.add("d-none");
            document.getElementById(divNoGato_1sId).classList.remove("d-none");
            showMessage("Algo deu errado!", 2);
            //console.error(error);
            setLoading(false);
        }
    )
}

function treatFormData(data) {

    
    return data
}

function loadTable(gato_1s) {
    $(`#${tblGato_1Id}`).DataTable({
        data: gato_1s, // TODO Deve estar assim: [ [ 1, "ModelA" ], [ 2, "ModelB" ] ]
        columns: [
            { title: "Id" },
            { title: "Nome" }
        ],
        autoWidth: false,
        columnDefs: [{
            targets: ['_all'],
            className: 'mdc-data-table__cell'
        }]
    });
}

document.addEventListener(contentLoadedEventListener, function(event) {
    document.getElementById(divContainerGato_1sId).classList.add("d-none");
    document.getElementById(divNoGato_1sId).classList.remove("d-none");

    const modalEl = document.getElementById(mdlGato_1Id);
    const modal = new mdb.Modal(modalEl);
    
    getGato_1sAndLoad();

    document.getElementById(btnAddId).onclick = function(evt) {
        const form = document.getElementById(frmGato_1Id);

        let data = form.serializeFormJSON();

        data = treatFormData(data);

        addGato_1(
            data,
            function() {
                setLoading(true);
                //setLoadingModal(true, document.getElementById(mdlGato_1Id)); // TODO Review
            }, function(result) {
                //setLoadingModal(false, document.getElementById(mdlGato_1Id)); // TODO Review
                modal.hide();
                if (result) {
                    showMessage("O/A Gato_1 foi adicionado!", 1);
                    getGato_1sAndLoad()
                } else {
                    showMessage("Algo deu errado!", 2);
                    setLoading(false);
                }
            }, function(error) {
                //setLoadingModal(false, document.getElementById(mdlGato_1Id)); // TODO Review
                modal.hide();
                showMessage("Algo deu errado!", 2);
                //console.error(error);
                setLoading(false);
            }
        )
    };
});