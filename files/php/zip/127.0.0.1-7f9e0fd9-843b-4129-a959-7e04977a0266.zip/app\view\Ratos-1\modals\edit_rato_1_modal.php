<div id="mdl-edit-rato-1" class="modal fade" tabindex="-1" aria-labelledby="edit-rato-1-title" aria-hidden="true" >
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="edit-rato-1-title">Atualizar Rato-1</h5>
                <button type="button" class="btn-close" data-mdb-dismiss="modal" aria-label="Fechar"></button>
            </div>
            <div class="modal-body">
                <form id="form-rato-1">
                   <div class="row">
                       <div class="col-12 col-sm-4 col-md-4 col-lg-4">
                            <div class="form-check">
                                <input
                                    class="form-check-input"
                                    type="checkbox"
                                    name="limpo_1"
                                    id="limpo-1"
                                    value="0"
                                />
                                <label class="form-check-label" for="limpo-1">
                                    Limpo-1
                                </label>
                            </div>
                        </div>
                   </div>
               </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-danger" data-mdb-dismiss="modal">
                    Cancelar
                </button>
                <button id="edit-rato-1" type="button" class="btn btn-primary">Atualizar</button>
            </div>
        </div>
    </div>
</div>