<form id="form-garruncho">
    <div class="row">        <div class="col-12 col-sm-4 col-md-4 col-lg-4">
            <div class="form-outline">
                <input name="tipo" type="number" id="tipo" class="form-control"
<?php
if (isset($_GET["id"]) && !is_null($_GET["id"]) && $_GET["id"] > -1) {
?>
    value="
<?php echo $_POST["tipo"]; ?>
    "
<?php
}
?>
                />
                <label class="form-label" for="tipo">Tipo</label>
            </div>
        </div>    </div></form>
<div class="row mt-3">
    <div class="col-12 col-sm-12 col-md-12 col-lg-12">
        <button id="edit-garruncho" type="button" class="btn btn-warning
<?php
if (!isset($_GET["id"]) || is_null($_GET["id"]) || $_GET["id"] <= -1) {
    echo "d-none";
}
?>
" garrunchoId="<?= (isset($_GET["id"]) && !is_null($_GET["id"]) && $_GET["id"] > -1) ? $_GET["id"] : "-1" ?>">Atualizar</button>

        <button id="add-garruncho" type="button" class="btn btn-success">Adicionar</button>
    </div>
</div>