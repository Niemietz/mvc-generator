<?php
namespace App\Model;

use App\Model\SuperClass\eModelList;
use App\Model\Girafa_1;
use App\Data\DAO;

class Girafa_1s extends eModelList
{
    public function read()
    {
        $result = false;

        $query = "SELECT g.id, ";
        $query .= "g.amazonense-1";
        $query .= " FROM girafas-1 g";

        try
        {
            $dao = new DAO();
            $sql = $dao->executeQuery($query);

            if(mysqli_num_rows($sql) > 0)
            {
                while($row = $sql->fetch_array())
                {
                    $girafa_1 = new Girafa_1();
                    $girafa_1->setId($row['id']);
                    $girafa_1->setAmazonense_1($row['amazonense-1']);

                    $this->add($girafa_1);
                }

                $result = true;
            }
        }
        catch(\Exception $error)
        {
            throw $error;
        }

        return $result;
    }
}