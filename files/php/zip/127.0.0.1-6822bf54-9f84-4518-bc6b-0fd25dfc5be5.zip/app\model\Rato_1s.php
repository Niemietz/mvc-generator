<?php
namespace App\Model;

use App\Model\SuperClass\eModelList;
use App\Model\Rato_1;
use App\Data\DAO;

class Rato_1s extends eModelList
{
    public function read()
    {
        $result = false;

        $query = "SELECT r.id, ";
        $query .= "r.limpo-1";
        $query .= " FROM ratos-1 r";

        try
        {
            $dao = new DAO();
            $sql = $dao->executeQuery($query);

            if(mysqli_num_rows($sql) > 0)
            {
                while($row = $sql->fetch_array())
                {
                    $rato_1 = new Rato_1();
                    $rato_1->setId($row['id']);
                    $rato_1->setLimpo_1($row['limpo-1']);

                    $this->add($rato_1);
                }

                $result = true;
            }
        }
        catch(\Exception $error)
        {
            throw $error;
        }

        return $result;
    }
}