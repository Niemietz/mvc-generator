import { addElefante_1, editElefante_1 } from './../api.js';

const elefante_1IdAttribute = "elefante-1Id";
const frmElefante_1Id = "form-elefante-1";
const btnEditId = "edit-elefante-1";
const btnAddId = "add-elefante-1";

function treatFormData(data) {
    data["tamanho_1"] = parseFloat(data["tamanho_1"])
    return data
}

document.addEventListener(contentLoadedEventListener, function(event) {
    document.getElementById(btnEditId).onclick = function(evt) {
        const elefante_1Id = this.getAttribute(elefante_1IdAttribute);

        const form = document.getElementById(frmElefante_1Id);

        let data = form.serializeFormJSON();

        data = treatFormData(data);

        editElefante_1(
            elefante_1Id,
            data,
            function() {
                setLoading(true);
            }, function(result) {
                if (result) {
                    showMessage("O/A Elefante_1 foi atualizado!", 1);
                } else {
                    showMessage("Algo deu errado!", 2);
                }
                setLoading(false);
            }, function(error) {
                showMessage("Algo deu errado!", 2);
                //console.error(error);
                setLoading(false);
            }
        )
    };

    document.getElementById(btnAddId).onclick = function(evt) {
        const form = document.getElementById(frmElefante_1Id);

        let data = form.serializeFormJSON();

        data = treatFormData(data);

        addElefante_1(
            data,
            function() {
                setLoading(true);
            }, function(result) {
                if (result) {
                    showMessage("O/A Elefante_1 foi atualizado!", 1);
                } else {
                    showMessage("Algo deu errado!", 2);
                }
                setLoading(false);
            }, function(error) {
                showMessage("Algo deu errado!", 2);
                //console.error(error);
                setLoading(false);
            }
        )
    };
});