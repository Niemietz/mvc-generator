<?php

namespace App\Controller;
    
use Src\Classes\Render;
    
class ControllerTeste_1 extends Render
{
    public function __construct()
    {
        parent::__construct();

        $this->setTitle("Página de teste-1");
        $this->setDescription("");
        $this->setKeywords(array(
        ));
        $this->setDirectory("Teste-1");

        $this->renderLayout();
    }
}
