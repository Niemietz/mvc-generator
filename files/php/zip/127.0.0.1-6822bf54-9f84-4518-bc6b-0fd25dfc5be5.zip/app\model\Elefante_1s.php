<?php
namespace App\Model;

use App\Model\SuperClass\eModelList;
use App\Model\Elefante_1;
use App\Data\DAO;

class Elefante_1s extends eModelList
{
    public function read()
    {
        $result = false;

        $query = "SELECT e.id, ";
        $query .= "e.tamanho-1";
        $query .= " FROM elefantes-1 e";

        try
        {
            $dao = new DAO();
            $sql = $dao->executeQuery($query);

            if(mysqli_num_rows($sql) > 0)
            {
                while($row = $sql->fetch_array())
                {
                    $elefante_1 = new Elefante_1();
                    $elefante_1->setId($row['id']);
                    $elefante_1->setTamanho_1($row['tamanho-1']);

                    $this->add($elefante_1);
                }

                $result = true;
            }
        }
        catch(\Exception $error)
        {
            throw $error;
        }

        return $result;
    }
}