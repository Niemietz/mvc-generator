<?php
namespace App\Model;

use App\Model\SuperClass\eModelList;
use App\Model\Jacare_1;
use App\Data\DAO;

class Jacare_1s extends eModelList
{
    public function read()
    {
        $result = false;

        $query = "SELECT j.id, ";
        $query .= "j.dente-1";
        $query .= " FROM jacares-1 j";

        try
        {
            $dao = new DAO();
            $sql = $dao->executeQuery($query);

            if(mysqli_num_rows($sql) > 0)
            {
                while($row = $sql->fetch_array())
                {
                    $jacare_1 = new Jacare_1();
                    $jacare_1->setId($row['id']);
                    $jacare_1->setDente_1($row['dente-1']);

                    $this->add($jacare_1);
                }

                $result = true;
            }
        }
        catch(\Exception $error)
        {
            throw $error;
        }

        return $result;
    }
}