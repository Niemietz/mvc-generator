<?php
namespace App\Model;

use App\Model\SuperClass\eModelList;
use App\Model\Gato_1;
use App\Data\DAO;

class Gato_1s extends eModelList
{
    public function read()
    {
        $result = false;

        $query = "SELECT g.id, ";
        $query .= "g.cor-1";
        $query .= " FROM gatos-1 g";

        try
        {
            $dao = new DAO();
            $sql = $dao->executeQuery($query);

            if(mysqli_num_rows($sql) > 0)
            {
                while($row = $sql->fetch_array())
                {
                    $gato_1 = new Gato_1();
                    $gato_1->setId($row['id']);
                    $gato_1->setCor_1($row['cor-1']);

                    $this->add($gato_1);
                }

                $result = true;
            }
        }
        catch(\Exception $error)
        {
            throw $error;
        }

        return $result;
    }
}