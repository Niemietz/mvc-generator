<?php
namespace App\Model;

use App\Model\SuperClass\eModel;

use App\Data\DAO;

class Girafa_1 extends eModel
{
    private $amazonense_1;
    
    function __construct()
    {
        parent::__construct();
        $this->amazonense_1 = -1;
    }

    public function read()
    {
        $result = false;

        $query = "SELECT ";
        $query .= "g.amazonense-1";
        $query .= " FROM girafas-1 g";
        $query .= " WHERE g.id = " . $this->getId();

        $dao = new DAO();
        $sql = $dao->executeQuery($query);

        if(mysqli_num_rows($sql) > 0)
        {
            if($row = $sql->fetch_assoc())
            {
                $this->setId($row['id']);
                $this->setAmazonense_1($row['amazonense-1']);
            }

            $result = true;
        }

        return $result;
    }

    public function insert()
    {
        $result = 0;

        $query = "SELECT g.id";
        $query .= " FROM girafas-1 g";
        $query .= " WHERE g.amazonense-1 = " . $this->getAmazonense_1();
        
        $dao = new DAO();
        $sql = $dao->executeQuery($query);

        if(mysqli_num_rows($sql) == 0)
        {
            $query = "INSERT INTO girafas-1(";
            $query .= "amazonense-1";
            $query .= ")";
            $query .= " VALUES (";
            $query .= $this->getAmazonense_1();
            $query .= ")";

            $girafa_1Id = $dao->executeQueryAndGetId($query);

            if($girafa_1Id > 0)
            {
                $this->setId($girafa_1Id);
                $result = $girafa_1Id;
            }
        }
        else
        {
            if($row = $sql->fetch_assoc())
            {
                $this->setId((int)$row["id"]);
                $result = (int)$row["id"];
            }
        }

        return $result;
    }

    public function update()
    {
        $result = false;

        if($this->getId() > 0)
        {
            $query = "UPDATE girafas-1 SET ";
            $query .= "amazonense-1 = " . $this->getAmazonense_1();
            $query .= " WHERE id = " . $this->getId();

            $dao = new DAO();
            if($dao->executeQueryAndGetNumberOfAffectedRows($query) > 0)
            {
                $result = true;
            }
        }

        return $result;
    }

    public function delete()
    {
        $result = false;

        if($this->getId() > 0)
        {
            $query = "DELETE FROM girafas-1";
            $query .= " WHERE id = " . $this->getId();

            try
            {
                $dao = new DAO();
                if($dao->executeQueryAndGetNumberOfAffectedRows($query))
                {
                    $result = true;
                }
            }
            catch(Exception $error)
            {
                throw $error;
            }
        }
        else
        {
            throw new \Exception("Could not delete Girafa_1 from database: Missing ID.");
        }

        return $result;
    }

    public function getAmazonense_1()
    {
        return $this->amazonense_1;
    }

    public function setAmazonense_1($amazonense_1)
    {
        $this->amazonense_1 = $amazonense_1;
    }

    public function jsonSerialize()
    {
        return array(
            'id' => $this->getId(),
            'amazonense_1' => $this->getAmazonense_1()
        );
    }
}