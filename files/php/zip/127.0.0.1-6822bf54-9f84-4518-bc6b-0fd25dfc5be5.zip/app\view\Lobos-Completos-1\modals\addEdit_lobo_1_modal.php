<div id="mdl-add-edit-lobo-1" class="modal fade" tabindex="-1" aria-labelledby="add-edit-lobo-1-title" aria-hidden="true" >
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="add-edit-lobo-1-title">Adicionar Lobo-1</h5>
                <button type="button" class="btn-close" data-mdb-dismiss="modal" aria-label="Fechar"></button>
            </div>
            <div class="modal-body">
                <form id="form-lobo-1">
                   <div class="row">
                       <div class="col-12 col-sm-4 col-md-4 col-lg-4">
                            <div class="form-outline">
                                <input name="matilha_1" type="text" id="matilha-1" class="form-control" />
                                <label class="form-label" for="matilha-1">Matilha-1</label>
                            </div>
                        </div>
                   </div>
               </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-danger" data-mdb-dismiss="modal">
                    Cancelar
                </button>
                <button id="add-edit-lobo-1" lobo-1Id="-1" type="button" class="btn btn-primary">Adicionar</button>
            </div>
        </div>
    </div>
</div>