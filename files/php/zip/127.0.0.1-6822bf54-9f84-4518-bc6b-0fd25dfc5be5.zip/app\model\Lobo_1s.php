<?php
namespace App\Model;

use App\Model\SuperClass\eModelList;
use App\Model\Lobo_1;
use App\Data\DAO;

class Lobo_1s extends eModelList
{
    public function read()
    {
        $result = false;

        $query = "SELECT l.id, ";
        $query .= "l.matilha-1";
        $query .= " FROM lobo-1 l";

        try
        {
            $dao = new DAO();
            $sql = $dao->executeQuery($query);

            if(mysqli_num_rows($sql) > 0)
            {
                while($row = $sql->fetch_array())
                {
                    $lobo_1 = new Lobo_1();
                    $lobo_1->setId($row['id']);
                    $lobo_1->setMatilha_1($row['matilha-1']);

                    $this->add($lobo_1);
                }

                $result = true;
            }
        }
        catch(\Exception $error)
        {
            throw $error;
        }

        return $result;
    }
}