<div class="row">
    <div class="col-12 col-sm-12 col-md-12 col-lg-12">
    <?php
        /*if (USEBREADCRUMB) {
            $breadcrumb = new Src\Classes\Breadcrumb();
            $breadcrumb->addBreadcrumb();
        }*/
    ?>
    </div>
</div>
<div class="row">
    <div id="container-lobo-1s" class="col-12 col-sm-12 col-md-12 col-lg-12 d-none">
        <table id="table-lobo-1" class="table"></table>
    </div>
    <div id="no-lobo-1s" class="col-12 col-sm-12 col-md-12 col-lg-12">
        <label>Nenhum(a) Lobo-1s encontrado(a)!</label>
    </div>
</div>