<?php
namespace App\Model;

use App\Model\SuperClass\eModelList;
use App\Model\Cachorro_1;
use App\Data\DAO;

class Cachorro_1s extends eModelList
{
    public function read()
    {
        $result = false;

        $query = "SELECT c.id, ";
        $query .= "c.raca-1";
        $query .= " FROM cachorros-1 c";

        try
        {
            $dao = new DAO();
            $sql = $dao->executeQuery($query);

            if(mysqli_num_rows($sql) > 0)
            {
                while($row = $sql->fetch_array())
                {
                    $cachorro_1 = new Cachorro_1();
                    $cachorro_1->setId($row['id']);
                    $cachorro_1->setRaca_1($row['raca-1']);

                    $this->add($cachorro_1);
                }

                $result = true;
            }
        }
        catch(\Exception $error)
        {
            throw $error;
        }

        return $result;
    }
}