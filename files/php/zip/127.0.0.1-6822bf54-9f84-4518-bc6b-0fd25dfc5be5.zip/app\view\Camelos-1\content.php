<div class="row">
    <div class="col-12 col-sm-12 col-md-12 col-lg-12">
    <?php
        /*if (USEBREADCRUMB) {
            $breadcrumb = new Src\Classes\Breadcrumb();
            $breadcrumb->addBreadcrumb();
        }*/
    ?>
    </div>
</div>
<div class="row">
    <div id="container-camelo-1s" class="col-12 col-sm-12 col-md-12 col-lg-12 d-none">
        <table id="table-camelo-1" class="table"></table>
    </div>
    <div id="no-camelo-1s" class="col-12 col-sm-12 col-md-12 col-lg-12">
        <label>Nenhum(a) Camelo-1s encontrado(a)!</label>
    </div>
</div>