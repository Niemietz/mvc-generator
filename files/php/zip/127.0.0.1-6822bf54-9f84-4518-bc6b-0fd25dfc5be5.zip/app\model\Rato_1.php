<?php
namespace App\Model;

use App\Model\SuperClass\eModel;

use App\Data\DAO;

class Rato_1 extends eModel
{
    private $limpo_1;
    
    function __construct()
    {
        parent::__construct();
        $this->limpo_1 = false;
    }

    public function read()
    {
        $result = false;

        $query = "SELECT ";
        $query .= "r.limpo-1";
        $query .= " FROM ratos-1 r";
        $query .= " WHERE r.id = " . $this->getId();

        $dao = new DAO();
        $sql = $dao->executeQuery($query);

        if(mysqli_num_rows($sql) > 0)
        {
            if($row = $sql->fetch_assoc())
            {
                $this->setId($row['id']);
                $this->setLimpo_1(($row['limpo-1'] == "1") ? true : false);
            }

            $result = true;
        }

        return $result;
    }

    public function insert()
    {
        $result = 0;

        $query = "SELECT r.id";
        $query .= " FROM ratos-1 r";
        $query .= " WHERE r.limpo-1 = " . $this->getLimpo_1();
        
        $dao = new DAO();
        $sql = $dao->executeQuery($query);

        if(mysqli_num_rows($sql) == 0)
        {
            $query = "INSERT INTO ratos-1(";
            $query .= "limpo-1";
            $query .= ")";
            $query .= " VALUES (";
            $query .= $this->getLimpo_1();
            $query .= ")";

            $rato_1Id = $dao->executeQueryAndGetId($query);

            if($rato_1Id > 0)
            {
                $this->setId($rato_1Id);
                $result = $rato_1Id;
            }
        }
        else
        {
            if($row = $sql->fetch_assoc())
            {
                $this->setId((int)$row["id"]);
                $result = (int)$row["id"];
            }
        }

        return $result;
    }

    public function update()
    {
        $result = false;

        if($this->getId() > 0)
        {
            $query = "UPDATE ratos-1 SET ";
            $query .= "limpo-1 = " . $this->getLimpo_1();
            $query .= " WHERE id = " . $this->getId();

            $dao = new DAO();
            if($dao->executeQueryAndGetNumberOfAffectedRows($query) > 0)
            {
                $result = true;
            }
        }

        return $result;
    }

    public function delete()
    {
        $result = false;

        if($this->getId() > 0)
        {
            $query = "DELETE FROM ratos-1";
            $query .= " WHERE id = " . $this->getId();

            try
            {
                $dao = new DAO();
                if($dao->executeQueryAndGetNumberOfAffectedRows($query))
                {
                    $result = true;
                }
            }
            catch(Exception $error)
            {
                throw $error;
            }
        }
        else
        {
            throw new \Exception("Could not delete Rato_1 from database: Missing ID.");
        }

        return $result;
    }

    public function getLimpo_1()
    {
        return $this->limpo_1;
    }

    public function setLimpo_1($limpo_1)
    {
        $this->limpo_1 = $limpo_1;
    }

    public function jsonSerialize()
    {
        return array(
            'id' => $this->getId(),
            'limpo_1' => $this->getLimpo_1()
        );
    }
}