<?php
namespace App\Model;

use App\Model\SuperClass\eModel;

use App\Data\DAO;

class Gato_1 extends eModel
{
    private $cor_1;
    
    function __construct()
    {
        parent::__construct();
        $this->cor_1 = '';
    }

    public function read()
    {
        $result = false;

        $query = "SELECT ";
        $query .= "g.cor-1";
        $query .= " FROM gatos-1 g";
        $query .= " WHERE g.id = " . $this->getId();

        $dao = new DAO();
        $sql = $dao->executeQuery($query);

        if(mysqli_num_rows($sql) > 0)
        {
            if($row = $sql->fetch_assoc())
            {
                $this->setId($row['id']);
                $this->setCor_1($row['cor-1']);
            }

            $result = true;
        }

        return $result;
    }

    public function insert()
    {
        $result = 0;

        $query = "SELECT g.id";
        $query .= " FROM gatos-1 g";
        $query .= " WHERE UPPER(g.cor-1) = UPPER('" . $this->getCor_1() . "')";
        
        $dao = new DAO();
        $sql = $dao->executeQuery($query);

        if(mysqli_num_rows($sql) == 0)
        {
            $query = "INSERT INTO gatos-1(";
            $query .= "cor-1";
            $query .= ")";
            $query .= " VALUES (";
            $query .= "'" . $this->getCor_1() . "'";
            $query .= ")";

            $gato_1Id = $dao->executeQueryAndGetId($query);

            if($gato_1Id > 0)
            {
                $this->setId($gato_1Id);
                $result = $gato_1Id;
            }
        }
        else
        {
            if($row = $sql->fetch_assoc())
            {
                $this->setId((int)$row["id"]);
                $result = (int)$row["id"];
            }
        }

        return $result;
    }

    public function update()
    {
        $result = false;

        if($this->getId() > 0)
        {
            $query = "UPDATE gatos-1 SET ";
            $query .= "cor-1 = '" . $this->getCor_1() . "'";
            $query .= " WHERE id = " . $this->getId();

            $dao = new DAO();
            if($dao->executeQueryAndGetNumberOfAffectedRows($query) > 0)
            {
                $result = true;
            }
        }

        return $result;
    }

    public function delete()
    {
        $result = false;

        if($this->getId() > 0)
        {
            $query = "DELETE FROM gatos-1";
            $query .= " WHERE id = " . $this->getId();

            try
            {
                $dao = new DAO();
                if($dao->executeQueryAndGetNumberOfAffectedRows($query))
                {
                    $result = true;
                }
            }
            catch(Exception $error)
            {
                throw $error;
            }
        }
        else
        {
            throw new \Exception("Could not delete Gato_1 from database: Missing ID.");
        }

        return $result;
    }

    public function getCor_1()
    {
        return $this->cor_1;
    }

    public function setCor_1($cor_1)
    {
        $this->cor_1 = $cor_1;
    }

    public function jsonSerialize()
    {
        return array(
            'id' => $this->getId(),
            'cor_1' => $this->getCor_1()
        );
    }
}