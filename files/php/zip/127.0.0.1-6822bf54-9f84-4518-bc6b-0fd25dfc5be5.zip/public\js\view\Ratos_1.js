import { editRato_1, getRato_1, getRato_1s } from './../api.js';

const tblRato_1Id = "table-rato-1"
const mdlRato_1Id = "mdl-edit-rato-1"
const frmRato_1Id = "form-rato-1";
const divContainerRato_1sId = "container-rato-1s";
const divNoRato_1sId = "no-rato-1s";
const btnEditId = "edit-rato-1";
const inpLimpo_1Id = "limpo-1";

function getEditButtonHTML() {
    const button = document.createElement("button");
    button.type = "button";
    button.setAttribute("data-mdb-toggle", "modal")
    button.setAttribute("data-mdb-target", `#${mdlRato_1Id}`)
    button.classList.add("btn");
    button.classList.add("btn-warning");
    button.innerHTML = "Atualizar";

    return button
}

function getRato_1sAndLoad() {
    getRato_1s(
        function() {
            setLoading(true);
        }, function(rato_1s) {
            if (rato_1s.length > 0) {
                loadTable(rato_1s);

                document.getElementById(divContainerRato_1sId).classList.remove("d-none");
                document.getElementById(divNoRato_1sId).classList.add("d-none");
            } else {
                document.getElementById(divContainerRato_1sId).classList.add("d-none");
                document.getElementById(divNoRato_1sId).classList.remove("d-none");
                showMessage("Algo deu errado!", 2);
            }
            setLoading(false);
        }, function(error) {
            document.getElementById(divContainerRato_1sId).classList.add("d-none");
            document.getElementById(divNoRato_1sId).classList.remove("d-none");
            showMessage("Algo deu errado!", 2);
            //console.error(error);
            setLoading(false);
        }
    )
}

function treatFormData(data) {

    data["limpo_1"] = (data["limpo_1"] == "true") ? true : false;
    
    return data
}

function loadTable(rato_1s) {
    rato_1s.forEach((rato_1) => {
        rato_1.push(getEditButtonHTML())
    });

    $(`#${tblRato_1Id}`).DataTable({
        data: rato_1s, // TODO Deve estar assim: [ [ 1, "ModelA" ], [ 2, "ModelB" ] ]
        columns: [
            { title: "Id" },
            { title: "Nome" },
            { title: "#" }
        ],
        autoWidth: false,
        columnDefs: [{
            targets: ['_all'],
            className: 'mdc-data-table__cell'
        }]
    });
}

document.addEventListener(contentLoadedEventListener, function(event) {
    document.getElementById(divContainerRato_1sId).classList.add("d-none");
    document.getElementById(divNoRato_1sId).classList.remove("d-none");

    const modalEl = document.getElementById(mdlRato_1Id);
    const modal = new mdb.Modal(modalEl);

    getRato_1sAndLoad();

    modalEl.addEventListener('show.mdb.modal', (event) => {
        const rato_1Id = -1; // TODO Review (Pegar da coluna da tabela)

        getRato_1(rato_1Id,
            function() {
                setLoading(true);
                //setLoadingModal(true, document.getElementById(mdlRato_1Id)); // TODO Review
            },
            function(rato_1) {
                document.getElementById(btnEditId).setAttribute(rato_1IdAttribute, rato_1Id)
               if (rato_1.limpo_1) {
                    document.getElementById(inpLimpo_1Id).checked = true;
                } else {
                    document.getElementById(inpLimpo_1Id).checked = false;
                }
                //setLoadingModal(false, document.getElementById(mdlRato_1Id)); // TODO Review
                setLoading(false);
            },
            function(error) {
                //setLoadingModal(false, document.getElementById(mdlRato_1Id)); // TODO Review
                modal.hide();
                showMessage("Algo deu errado!", 2);
                //console.error(error);
                setLoading(false);
            }
        )
    })

    document.getElementById(btnEditId).onclick = function(evt) {
        const rato_1Id = parseInt(this.getAttribute(rato_1IdAttribute))

        const form = document.getElementById(frmRato_1Id);

        let data = form.serializeFormJSON();

        data = treatFormData(data);

        editRato_1(
            rato_1Id,
            data,
            function() {
                setLoading(true);
                //setLoadingModal(true, document.getElementById(mdlRato_1Id)); // TODO Review
            }, function(result) {
                //setLoadingModal(false, document.getElementById(mdlRato_1Id)); // TODO Review
                modal.hide();
                if (result) {
                    showMessage("O/A Rato_1 foi atualizado!", 1);
                    getRato_1sAndLoad()
                } else {
                    showMessage("Algo deu errado!", 2);
                    setLoading(false);
                }
            }, function(error) {
                //setLoadingModal(false, document.getElementById(mdlRato_1Id)); // TODO Review
                modal.hide();
                showMessage("Algo deu errado!", 2);
                //console.error(error);
                setLoading(false);
            }
        )
    };
});