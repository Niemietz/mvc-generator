<?php
namespace App\Model\SuperClass;

use App\Data\DAO;

abstract class eSuper
{

}