<?php

namespace App\Controller;
    
use Src\Classes\Render;
    
class ControllerGirafas_1 extends Render
{
    public function __construct()
    {
        parent::__construct();

        $this->setTitle("Girafas-1");
        $this->setDescription("");
        $this->setKeywords(array(
        ));
        $this->setDirectory("Girafas-1");

        $this->renderLayout();
    }
}
