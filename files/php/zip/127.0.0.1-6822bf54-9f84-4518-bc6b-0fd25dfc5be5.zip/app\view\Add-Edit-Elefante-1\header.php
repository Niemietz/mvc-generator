<script type="module" src="<?= DIRJS . '/view/Add_Edit_Elefante_1.js' ?>"></script>
    <?php
    if(file_exists(DIRREQ . "app/view/topbar.php"))
    {
        include(DIRREQ . "app/view/topbar.php");
    }
?>
<div class="row">
    <div class="col-12 col-sm-12 col-md-12 col-lg-12 text-center text-dark">
        <h1>Adicionar / Editar Elefante-1</h1>
    </div>
</div>