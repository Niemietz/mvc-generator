const apiLink = "/api";

/**
 * It gets Cachorro_1s list
 * 
 * @function beforeSend - beforeSend function
 * @function onSuccess - On success function
 * @function onError - On error function
 */
export function getCachorro_1s(beforeSend, onSuccess, onError)
{
    const afterSuccess = function(response)
    {
        if(response.error == null && response.result != null)
        {
            if(onSuccess != null)
            {
                onSuccess(response.result);
            }
        }
        else
        {
            if(onError != null)
            {
                onError(response.error);
            }
        }
    };

    $.ajax({
        url: `${apiLink}/cachorro_1s`,
        dataType: "json",
        "beforeSend": function()
        {
            if(beforeSend != null)
            {
                beforeSend();
            }
        },
        success: function(response)
        {
            afterSuccess(response);
        },
        error: function(error)
        {
            if(error.status == 200 && error.statusText == "OK")
            {
                error.responseText = jQuery.parseJSON(error.responseText);

                const response = {};
                response["result"] = error.responseText.result;
                response["error"] = error.responseText.error;

                afterSuccess(response);
            }
            else
            {
                if(onError != null)
                {
                    onError(error);
                }
            }
        }
    });
}

/**
 * It gets a(n) Cachorro_1
 * 
 * @param {Number} cachorro_1Id - Cachorro_1 ID
 * @function beforeSend - beforeSend function
 * @function onSuccess - On success function
 * @function onError - On error function
 */
export function getCachorro_1(cachorro_1Id, beforeSend, onSuccess, onError)
{
    const afterSuccess = function(response)
    {
        if(response.error == null && response.result != null)
        {
            if(onSuccess != null)
            {
                onSuccess(response.result);
            }
        }
        else
        {
            if(onError != null)
            {
                onError(response.error);
            }
        }
    };

    $.ajax({
        url: `${apiLink}/cachorro_1/${cachorro_1Id}`,
        method: "GET",
        dataType: "json",
        "beforeSend": function()
        {
            if(beforeSend != null)
            {
                beforeSend();
            }
        },
        success: function(response)
        {
            afterSuccess(response);
        },
        error: function(error)
        {
            if(error.status == 200 && error.statusText == "OK")
            {
                error.responseText = jQuery.parseJSON(error.responseText);

                const response = {};
                response["result"] = error.responseText.result;
                response["error"] = error.responseText.error;

                afterSuccess(response);
            }
            else
            {
                if(onError != null)
                {
                    onError(error);
                }
            }
        }
    });
}

/**
 * It adds a(n) Cachorro_1
 * 
 * @param {Object} data - Cachorro_1 data
 * @function beforeSend - beforeSend function
 * @function onSuccess - On success function
 * @function onError - On error function
 */
export function addCachorro_1(data, beforeSend, onSuccess, onError)
{
    const afterSuccess = function(response)
    {
        if(response.error == null && response.result != null 
            && response.result > 0)                 // UNIQUE CONDITION
        {
            if(onSuccess != null)
            {
                onSuccess(response.result);
            }
        }
        else
        {
            if(onError != null)
            {
                onError(response.error);
            }
        }
    };

    $.ajax({
        url: `${apiLink}/add_cachorro_1`,
        dataType: "json",
        method: "POST",
        data: data,
        "beforeSend": function()
        {
            if(beforeSend != null)
            {
                beforeSend();
            }
        },
        success: function(response)
        {
            afterSuccess(response);
        },
        error: function(error)
        {
            if(error.status == 200 && error.statusText == "OK")
            {
                error.responseText = jQuery.parseJSON(error.responseText);

                const response = {};
                response["result"] = error.responseText.result;
                response["error"] = error.responseText.error;

                afterSuccess(response);
            }
            else
            {
                if(onError != null)
                {
                    onError(error);
                }
            }
        }
    });
}

/**
 * It updates a(n) Cachorro_1
 * 
 * @param {Number} cachorro_1Id - Cachorro_1 ID
 * @param {Object} data - Cachorro_1 data
 * @function beforeSend - beforeSend function
 * @function onSuccess - On success function
 * @function onError - On error function
 */
export function editCachorro_1(cachorro_1Id, 
data, beforeSend, onSuccess, onError)
{
    const afterSuccess = function(response)
    {
        if(response.error == null && response.result != null
            && response.result == true)                    // UNIQUE CONDITION
        {
            if(onSuccess != null)
            {
                onSuccess(response.result);
            }
        }
        else
        {
            if(onError != null)
            {
                onError(response.error);
            }
        }
    };

    $.ajax({
        url: `${apiLink}/edit_cachorro_1/${cachorro_1Id}`,
        method: "POST",
        dataType: "json",
        data: data,
        "beforeSend": function()
        {
            if(beforeSend != null)
            {
                beforeSend();
            }
        },
        success: function(response)
        {
            afterSuccess(response);
        },
        error: function(error)
        {
            if(error.status == 200 && error.statusText == "OK")
            {
                error.responseText = jQuery.parseJSON(error.responseText);

                const response = {};
                response["result"] = error.responseText.result;
                response["error"] = error.responseText.error;

                afterSuccess(response);
            }
            else
            {
                if(onError != null)
                {
                    onError(error);
                }
            }
        }
    });
}
    
/**
 * It deletes a(n) Cachorro_1
 * 
 * @param {Number} cachorro_1Id - Cachorro_1 ID
 * @function beforeSend - beforeSend function
 * @function onSuccess - On success function
 * @function onError - On error function
 */
export function deleteCachorro_1(cachorro_1Id, beforeSend, onSuccess, onError)
{
    const afterSuccess = function(response)
    {
        if(response.error == null && response.result != null
            && response.result == true)                    // UNIQUE CONDITION
        {
            if(onSuccess != null)
            {
                onSuccess(response.result);
            }
        }
        else
        {
            if(onError != null)
            {
                onError(response.error);
            }
        }
    };

    $.ajax({
        url: `${apiLink}/delete_cachorro_1/${cachorro_1Id}`,
        method: "GET",
        dataType: "json",
        "beforeSend": function()
        {
            if(beforeSend != null)
            {
                beforeSend();
            }
        },
        success: function(response)
        {
            afterSuccess(response);
        },
        error: function(error)
        {
            if(error.status == 200 && error.statusText == "OK")
            {
                error.responseText = jQuery.parseJSON(error.responseText);

                const response = {};
                response["result"] = error.responseText.result;
                response["error"] = error.responseText.error;

                afterSuccess(response);
            }
            else
            {
                if(onError != null)
                {
                    onError(error);
                }
            }
        }
    });
}
/**
 * It gets Elefante_1s list
 * 
 * @function beforeSend - beforeSend function
 * @function onSuccess - On success function
 * @function onError - On error function
 */
export function getElefante_1s(beforeSend, onSuccess, onError)
{
    const afterSuccess = function(response)
    {
        if(response.error == null && response.result != null)
        {
            if(onSuccess != null)
            {
                onSuccess(response.result);
            }
        }
        else
        {
            if(onError != null)
            {
                onError(response.error);
            }
        }
    };

    $.ajax({
        url: `${apiLink}/elefante_1s`,
        dataType: "json",
        "beforeSend": function()
        {
            if(beforeSend != null)
            {
                beforeSend();
            }
        },
        success: function(response)
        {
            afterSuccess(response);
        },
        error: function(error)
        {
            if(error.status == 200 && error.statusText == "OK")
            {
                error.responseText = jQuery.parseJSON(error.responseText);

                const response = {};
                response["result"] = error.responseText.result;
                response["error"] = error.responseText.error;

                afterSuccess(response);
            }
            else
            {
                if(onError != null)
                {
                    onError(error);
                }
            }
        }
    });
}

/**
 * It gets a(n) Elefante_1
 * 
 * @param {Number} elefante_1Id - Elefante_1 ID
 * @function beforeSend - beforeSend function
 * @function onSuccess - On success function
 * @function onError - On error function
 */
export function getElefante_1(elefante_1Id, beforeSend, onSuccess, onError)
{
    const afterSuccess = function(response)
    {
        if(response.error == null && response.result != null)
        {
            if(onSuccess != null)
            {
                onSuccess(response.result);
            }
        }
        else
        {
            if(onError != null)
            {
                onError(response.error);
            }
        }
    };

    $.ajax({
        url: `${apiLink}/elefante_1/${elefante_1Id}`,
        method: "GET",
        dataType: "json",
        "beforeSend": function()
        {
            if(beforeSend != null)
            {
                beforeSend();
            }
        },
        success: function(response)
        {
            afterSuccess(response);
        },
        error: function(error)
        {
            if(error.status == 200 && error.statusText == "OK")
            {
                error.responseText = jQuery.parseJSON(error.responseText);

                const response = {};
                response["result"] = error.responseText.result;
                response["error"] = error.responseText.error;

                afterSuccess(response);
            }
            else
            {
                if(onError != null)
                {
                    onError(error);
                }
            }
        }
    });
}

/**
 * It adds a(n) Elefante_1
 * 
 * @param {Object} data - Elefante_1 data
 * @function beforeSend - beforeSend function
 * @function onSuccess - On success function
 * @function onError - On error function
 */
export function addElefante_1(data, beforeSend, onSuccess, onError)
{
    const afterSuccess = function(response)
    {
        if(response.error == null && response.result != null 
            && response.result > 0)                 // UNIQUE CONDITION
        {
            if(onSuccess != null)
            {
                onSuccess(response.result);
            }
        }
        else
        {
            if(onError != null)
            {
                onError(response.error);
            }
        }
    };

    $.ajax({
        url: `${apiLink}/add_elefante_1`,
        dataType: "json",
        method: "POST",
        data: data,
        "beforeSend": function()
        {
            if(beforeSend != null)
            {
                beforeSend();
            }
        },
        success: function(response)
        {
            afterSuccess(response);
        },
        error: function(error)
        {
            if(error.status == 200 && error.statusText == "OK")
            {
                error.responseText = jQuery.parseJSON(error.responseText);

                const response = {};
                response["result"] = error.responseText.result;
                response["error"] = error.responseText.error;

                afterSuccess(response);
            }
            else
            {
                if(onError != null)
                {
                    onError(error);
                }
            }
        }
    });
}

/**
 * It updates a(n) Elefante_1
 * 
 * @param {Number} elefante_1Id - Elefante_1 ID
 * @param {Object} data - Elefante_1 data
 * @function beforeSend - beforeSend function
 * @function onSuccess - On success function
 * @function onError - On error function
 */
export function editElefante_1(elefante_1Id, 
data, beforeSend, onSuccess, onError)
{
    const afterSuccess = function(response)
    {
        if(response.error == null && response.result != null
            && response.result == true)                    // UNIQUE CONDITION
        {
            if(onSuccess != null)
            {
                onSuccess(response.result);
            }
        }
        else
        {
            if(onError != null)
            {
                onError(response.error);
            }
        }
    };

    $.ajax({
        url: `${apiLink}/edit_elefante_1/${elefante_1Id}`,
        method: "POST",
        dataType: "json",
        data: data,
        "beforeSend": function()
        {
            if(beforeSend != null)
            {
                beforeSend();
            }
        },
        success: function(response)
        {
            afterSuccess(response);
        },
        error: function(error)
        {
            if(error.status == 200 && error.statusText == "OK")
            {
                error.responseText = jQuery.parseJSON(error.responseText);

                const response = {};
                response["result"] = error.responseText.result;
                response["error"] = error.responseText.error;

                afterSuccess(response);
            }
            else
            {
                if(onError != null)
                {
                    onError(error);
                }
            }
        }
    });
}
    
/**
 * It deletes a(n) Elefante_1
 * 
 * @param {Number} elefante_1Id - Elefante_1 ID
 * @function beforeSend - beforeSend function
 * @function onSuccess - On success function
 * @function onError - On error function
 */
export function deleteElefante_1(elefante_1Id, beforeSend, onSuccess, onError)
{
    const afterSuccess = function(response)
    {
        if(response.error == null && response.result != null
            && response.result == true)                    // UNIQUE CONDITION
        {
            if(onSuccess != null)
            {
                onSuccess(response.result);
            }
        }
        else
        {
            if(onError != null)
            {
                onError(response.error);
            }
        }
    };

    $.ajax({
        url: `${apiLink}/delete_elefante_1/${elefante_1Id}`,
        method: "GET",
        dataType: "json",
        "beforeSend": function()
        {
            if(beforeSend != null)
            {
                beforeSend();
            }
        },
        success: function(response)
        {
            afterSuccess(response);
        },
        error: function(error)
        {
            if(error.status == 200 && error.statusText == "OK")
            {
                error.responseText = jQuery.parseJSON(error.responseText);

                const response = {};
                response["result"] = error.responseText.result;
                response["error"] = error.responseText.error;

                afterSuccess(response);
            }
            else
            {
                if(onError != null)
                {
                    onError(error);
                }
            }
        }
    });
}
/**
 * It gets Gato_1s list
 * 
 * @function beforeSend - beforeSend function
 * @function onSuccess - On success function
 * @function onError - On error function
 */
export function getGato_1s(beforeSend, onSuccess, onError)
{
    const afterSuccess = function(response)
    {
        if(response.error == null && response.result != null)
        {
            if(onSuccess != null)
            {
                onSuccess(response.result);
            }
        }
        else
        {
            if(onError != null)
            {
                onError(response.error);
            }
        }
    };

    $.ajax({
        url: `${apiLink}/gato_1s`,
        dataType: "json",
        "beforeSend": function()
        {
            if(beforeSend != null)
            {
                beforeSend();
            }
        },
        success: function(response)
        {
            afterSuccess(response);
        },
        error: function(error)
        {
            if(error.status == 200 && error.statusText == "OK")
            {
                error.responseText = jQuery.parseJSON(error.responseText);

                const response = {};
                response["result"] = error.responseText.result;
                response["error"] = error.responseText.error;

                afterSuccess(response);
            }
            else
            {
                if(onError != null)
                {
                    onError(error);
                }
            }
        }
    });
}

/**
 * It gets a(n) Gato_1
 * 
 * @param {Number} gato_1Id - Gato_1 ID
 * @function beforeSend - beforeSend function
 * @function onSuccess - On success function
 * @function onError - On error function
 */
export function getGato_1(gato_1Id, beforeSend, onSuccess, onError)
{
    const afterSuccess = function(response)
    {
        if(response.error == null && response.result != null)
        {
            if(onSuccess != null)
            {
                onSuccess(response.result);
            }
        }
        else
        {
            if(onError != null)
            {
                onError(response.error);
            }
        }
    };

    $.ajax({
        url: `${apiLink}/gato_1/${gato_1Id}`,
        method: "GET",
        dataType: "json",
        "beforeSend": function()
        {
            if(beforeSend != null)
            {
                beforeSend();
            }
        },
        success: function(response)
        {
            afterSuccess(response);
        },
        error: function(error)
        {
            if(error.status == 200 && error.statusText == "OK")
            {
                error.responseText = jQuery.parseJSON(error.responseText);

                const response = {};
                response["result"] = error.responseText.result;
                response["error"] = error.responseText.error;

                afterSuccess(response);
            }
            else
            {
                if(onError != null)
                {
                    onError(error);
                }
            }
        }
    });
}

/**
 * It adds a(n) Gato_1
 * 
 * @param {Object} data - Gato_1 data
 * @function beforeSend - beforeSend function
 * @function onSuccess - On success function
 * @function onError - On error function
 */
export function addGato_1(data, beforeSend, onSuccess, onError)
{
    const afterSuccess = function(response)
    {
        if(response.error == null && response.result != null 
            && response.result > 0)                 // UNIQUE CONDITION
        {
            if(onSuccess != null)
            {
                onSuccess(response.result);
            }
        }
        else
        {
            if(onError != null)
            {
                onError(response.error);
            }
        }
    };

    $.ajax({
        url: `${apiLink}/add_gato_1`,
        dataType: "json",
        method: "POST",
        data: data,
        "beforeSend": function()
        {
            if(beforeSend != null)
            {
                beforeSend();
            }
        },
        success: function(response)
        {
            afterSuccess(response);
        },
        error: function(error)
        {
            if(error.status == 200 && error.statusText == "OK")
            {
                error.responseText = jQuery.parseJSON(error.responseText);

                const response = {};
                response["result"] = error.responseText.result;
                response["error"] = error.responseText.error;

                afterSuccess(response);
            }
            else
            {
                if(onError != null)
                {
                    onError(error);
                }
            }
        }
    });
}

/**
 * It updates a(n) Gato_1
 * 
 * @param {Number} gato_1Id - Gato_1 ID
 * @param {Object} data - Gato_1 data
 * @function beforeSend - beforeSend function
 * @function onSuccess - On success function
 * @function onError - On error function
 */
export function editGato_1(gato_1Id, 
data, beforeSend, onSuccess, onError)
{
    const afterSuccess = function(response)
    {
        if(response.error == null && response.result != null
            && response.result == true)                    // UNIQUE CONDITION
        {
            if(onSuccess != null)
            {
                onSuccess(response.result);
            }
        }
        else
        {
            if(onError != null)
            {
                onError(response.error);
            }
        }
    };

    $.ajax({
        url: `${apiLink}/edit_gato_1/${gato_1Id}`,
        method: "POST",
        dataType: "json",
        data: data,
        "beforeSend": function()
        {
            if(beforeSend != null)
            {
                beforeSend();
            }
        },
        success: function(response)
        {
            afterSuccess(response);
        },
        error: function(error)
        {
            if(error.status == 200 && error.statusText == "OK")
            {
                error.responseText = jQuery.parseJSON(error.responseText);

                const response = {};
                response["result"] = error.responseText.result;
                response["error"] = error.responseText.error;

                afterSuccess(response);
            }
            else
            {
                if(onError != null)
                {
                    onError(error);
                }
            }
        }
    });
}
    
/**
 * It deletes a(n) Gato_1
 * 
 * @param {Number} gato_1Id - Gato_1 ID
 * @function beforeSend - beforeSend function
 * @function onSuccess - On success function
 * @function onError - On error function
 */
export function deleteGato_1(gato_1Id, beforeSend, onSuccess, onError)
{
    const afterSuccess = function(response)
    {
        if(response.error == null && response.result != null
            && response.result == true)                    // UNIQUE CONDITION
        {
            if(onSuccess != null)
            {
                onSuccess(response.result);
            }
        }
        else
        {
            if(onError != null)
            {
                onError(response.error);
            }
        }
    };

    $.ajax({
        url: `${apiLink}/delete_gato_1/${gato_1Id}`,
        method: "GET",
        dataType: "json",
        "beforeSend": function()
        {
            if(beforeSend != null)
            {
                beforeSend();
            }
        },
        success: function(response)
        {
            afterSuccess(response);
        },
        error: function(error)
        {
            if(error.status == 200 && error.statusText == "OK")
            {
                error.responseText = jQuery.parseJSON(error.responseText);

                const response = {};
                response["result"] = error.responseText.result;
                response["error"] = error.responseText.error;

                afterSuccess(response);
            }
            else
            {
                if(onError != null)
                {
                    onError(error);
                }
            }
        }
    });
}
/**
 * It gets Rato_1s list
 * 
 * @function beforeSend - beforeSend function
 * @function onSuccess - On success function
 * @function onError - On error function
 */
export function getRato_1s(beforeSend, onSuccess, onError)
{
    const afterSuccess = function(response)
    {
        if(response.error == null && response.result != null)
        {
            if(onSuccess != null)
            {
                onSuccess(response.result);
            }
        }
        else
        {
            if(onError != null)
            {
                onError(response.error);
            }
        }
    };

    $.ajax({
        url: `${apiLink}/rato_1s`,
        dataType: "json",
        "beforeSend": function()
        {
            if(beforeSend != null)
            {
                beforeSend();
            }
        },
        success: function(response)
        {
            afterSuccess(response);
        },
        error: function(error)
        {
            if(error.status == 200 && error.statusText == "OK")
            {
                error.responseText = jQuery.parseJSON(error.responseText);

                const response = {};
                response["result"] = error.responseText.result;
                response["error"] = error.responseText.error;

                afterSuccess(response);
            }
            else
            {
                if(onError != null)
                {
                    onError(error);
                }
            }
        }
    });
}

/**
 * It gets a(n) Rato_1
 * 
 * @param {Number} rato_1Id - Rato_1 ID
 * @function beforeSend - beforeSend function
 * @function onSuccess - On success function
 * @function onError - On error function
 */
export function getRato_1(rato_1Id, beforeSend, onSuccess, onError)
{
    const afterSuccess = function(response)
    {
        if(response.error == null && response.result != null)
        {
            if(onSuccess != null)
            {
                onSuccess(response.result);
            }
        }
        else
        {
            if(onError != null)
            {
                onError(response.error);
            }
        }
    };

    $.ajax({
        url: `${apiLink}/rato_1/${rato_1Id}`,
        method: "GET",
        dataType: "json",
        "beforeSend": function()
        {
            if(beforeSend != null)
            {
                beforeSend();
            }
        },
        success: function(response)
        {
            afterSuccess(response);
        },
        error: function(error)
        {
            if(error.status == 200 && error.statusText == "OK")
            {
                error.responseText = jQuery.parseJSON(error.responseText);

                const response = {};
                response["result"] = error.responseText.result;
                response["error"] = error.responseText.error;

                afterSuccess(response);
            }
            else
            {
                if(onError != null)
                {
                    onError(error);
                }
            }
        }
    });
}

/**
 * It adds a(n) Rato_1
 * 
 * @param {Object} data - Rato_1 data
 * @function beforeSend - beforeSend function
 * @function onSuccess - On success function
 * @function onError - On error function
 */
export function addRato_1(data, beforeSend, onSuccess, onError)
{
    const afterSuccess = function(response)
    {
        if(response.error == null && response.result != null 
            && response.result > 0)                 // UNIQUE CONDITION
        {
            if(onSuccess != null)
            {
                onSuccess(response.result);
            }
        }
        else
        {
            if(onError != null)
            {
                onError(response.error);
            }
        }
    };

    $.ajax({
        url: `${apiLink}/add_rato_1`,
        dataType: "json",
        method: "POST",
        data: data,
        "beforeSend": function()
        {
            if(beforeSend != null)
            {
                beforeSend();
            }
        },
        success: function(response)
        {
            afterSuccess(response);
        },
        error: function(error)
        {
            if(error.status == 200 && error.statusText == "OK")
            {
                error.responseText = jQuery.parseJSON(error.responseText);

                const response = {};
                response["result"] = error.responseText.result;
                response["error"] = error.responseText.error;

                afterSuccess(response);
            }
            else
            {
                if(onError != null)
                {
                    onError(error);
                }
            }
        }
    });
}

/**
 * It updates a(n) Rato_1
 * 
 * @param {Number} rato_1Id - Rato_1 ID
 * @param {Object} data - Rato_1 data
 * @function beforeSend - beforeSend function
 * @function onSuccess - On success function
 * @function onError - On error function
 */
export function editRato_1(rato_1Id, 
data, beforeSend, onSuccess, onError)
{
    const afterSuccess = function(response)
    {
        if(response.error == null && response.result != null
            && response.result == true)                    // UNIQUE CONDITION
        {
            if(onSuccess != null)
            {
                onSuccess(response.result);
            }
        }
        else
        {
            if(onError != null)
            {
                onError(response.error);
            }
        }
    };

    $.ajax({
        url: `${apiLink}/edit_rato_1/${rato_1Id}`,
        method: "POST",
        dataType: "json",
        data: data,
        "beforeSend": function()
        {
            if(beforeSend != null)
            {
                beforeSend();
            }
        },
        success: function(response)
        {
            afterSuccess(response);
        },
        error: function(error)
        {
            if(error.status == 200 && error.statusText == "OK")
            {
                error.responseText = jQuery.parseJSON(error.responseText);

                const response = {};
                response["result"] = error.responseText.result;
                response["error"] = error.responseText.error;

                afterSuccess(response);
            }
            else
            {
                if(onError != null)
                {
                    onError(error);
                }
            }
        }
    });
}
    
/**
 * It deletes a(n) Rato_1
 * 
 * @param {Number} rato_1Id - Rato_1 ID
 * @function beforeSend - beforeSend function
 * @function onSuccess - On success function
 * @function onError - On error function
 */
export function deleteRato_1(rato_1Id, beforeSend, onSuccess, onError)
{
    const afterSuccess = function(response)
    {
        if(response.error == null && response.result != null
            && response.result == true)                    // UNIQUE CONDITION
        {
            if(onSuccess != null)
            {
                onSuccess(response.result);
            }
        }
        else
        {
            if(onError != null)
            {
                onError(response.error);
            }
        }
    };

    $.ajax({
        url: `${apiLink}/delete_rato_1/${rato_1Id}`,
        method: "GET",
        dataType: "json",
        "beforeSend": function()
        {
            if(beforeSend != null)
            {
                beforeSend();
            }
        },
        success: function(response)
        {
            afterSuccess(response);
        },
        error: function(error)
        {
            if(error.status == 200 && error.statusText == "OK")
            {
                error.responseText = jQuery.parseJSON(error.responseText);

                const response = {};
                response["result"] = error.responseText.result;
                response["error"] = error.responseText.error;

                afterSuccess(response);
            }
            else
            {
                if(onError != null)
                {
                    onError(error);
                }
            }
        }
    });
}
/**
 * It gets Lobo_1s list
 * 
 * @function beforeSend - beforeSend function
 * @function onSuccess - On success function
 * @function onError - On error function
 */
export function getLobo_1s(beforeSend, onSuccess, onError)
{
    const afterSuccess = function(response)
    {
        if(response.error == null && response.result != null)
        {
            if(onSuccess != null)
            {
                onSuccess(response.result);
            }
        }
        else
        {
            if(onError != null)
            {
                onError(response.error);
            }
        }
    };

    $.ajax({
        url: `${apiLink}/lobo_1s`,
        dataType: "json",
        "beforeSend": function()
        {
            if(beforeSend != null)
            {
                beforeSend();
            }
        },
        success: function(response)
        {
            afterSuccess(response);
        },
        error: function(error)
        {
            if(error.status == 200 && error.statusText == "OK")
            {
                error.responseText = jQuery.parseJSON(error.responseText);

                const response = {};
                response["result"] = error.responseText.result;
                response["error"] = error.responseText.error;

                afterSuccess(response);
            }
            else
            {
                if(onError != null)
                {
                    onError(error);
                }
            }
        }
    });
}

/**
 * It gets a(n) Lobo_1
 * 
 * @param {Number} lobo_1Id - Lobo_1 ID
 * @function beforeSend - beforeSend function
 * @function onSuccess - On success function
 * @function onError - On error function
 */
export function getLobo_1(lobo_1Id, beforeSend, onSuccess, onError)
{
    const afterSuccess = function(response)
    {
        if(response.error == null && response.result != null)
        {
            if(onSuccess != null)
            {
                onSuccess(response.result);
            }
        }
        else
        {
            if(onError != null)
            {
                onError(response.error);
            }
        }
    };

    $.ajax({
        url: `${apiLink}/lobo_1/${lobo_1Id}`,
        method: "GET",
        dataType: "json",
        "beforeSend": function()
        {
            if(beforeSend != null)
            {
                beforeSend();
            }
        },
        success: function(response)
        {
            afterSuccess(response);
        },
        error: function(error)
        {
            if(error.status == 200 && error.statusText == "OK")
            {
                error.responseText = jQuery.parseJSON(error.responseText);

                const response = {};
                response["result"] = error.responseText.result;
                response["error"] = error.responseText.error;

                afterSuccess(response);
            }
            else
            {
                if(onError != null)
                {
                    onError(error);
                }
            }
        }
    });
}

/**
 * It adds a(n) Lobo_1
 * 
 * @param {Object} data - Lobo_1 data
 * @function beforeSend - beforeSend function
 * @function onSuccess - On success function
 * @function onError - On error function
 */
export function addLobo_1(data, beforeSend, onSuccess, onError)
{
    const afterSuccess = function(response)
    {
        if(response.error == null && response.result != null 
            && response.result > 0)                 // UNIQUE CONDITION
        {
            if(onSuccess != null)
            {
                onSuccess(response.result);
            }
        }
        else
        {
            if(onError != null)
            {
                onError(response.error);
            }
        }
    };

    $.ajax({
        url: `${apiLink}/add_lobo_1`,
        dataType: "json",
        method: "POST",
        data: data,
        "beforeSend": function()
        {
            if(beforeSend != null)
            {
                beforeSend();
            }
        },
        success: function(response)
        {
            afterSuccess(response);
        },
        error: function(error)
        {
            if(error.status == 200 && error.statusText == "OK")
            {
                error.responseText = jQuery.parseJSON(error.responseText);

                const response = {};
                response["result"] = error.responseText.result;
                response["error"] = error.responseText.error;

                afterSuccess(response);
            }
            else
            {
                if(onError != null)
                {
                    onError(error);
                }
            }
        }
    });
}

/**
 * It updates a(n) Lobo_1
 * 
 * @param {Number} lobo_1Id - Lobo_1 ID
 * @param {Object} data - Lobo_1 data
 * @function beforeSend - beforeSend function
 * @function onSuccess - On success function
 * @function onError - On error function
 */
export function editLobo_1(lobo_1Id, 
data, beforeSend, onSuccess, onError)
{
    const afterSuccess = function(response)
    {
        if(response.error == null && response.result != null
            && response.result == true)                    // UNIQUE CONDITION
        {
            if(onSuccess != null)
            {
                onSuccess(response.result);
            }
        }
        else
        {
            if(onError != null)
            {
                onError(response.error);
            }
        }
    };

    $.ajax({
        url: `${apiLink}/edit_lobo_1/${lobo_1Id}`,
        method: "POST",
        dataType: "json",
        data: data,
        "beforeSend": function()
        {
            if(beforeSend != null)
            {
                beforeSend();
            }
        },
        success: function(response)
        {
            afterSuccess(response);
        },
        error: function(error)
        {
            if(error.status == 200 && error.statusText == "OK")
            {
                error.responseText = jQuery.parseJSON(error.responseText);

                const response = {};
                response["result"] = error.responseText.result;
                response["error"] = error.responseText.error;

                afterSuccess(response);
            }
            else
            {
                if(onError != null)
                {
                    onError(error);
                }
            }
        }
    });
}
    
/**
 * It deletes a(n) Lobo_1
 * 
 * @param {Number} lobo_1Id - Lobo_1 ID
 * @function beforeSend - beforeSend function
 * @function onSuccess - On success function
 * @function onError - On error function
 */
export function deleteLobo_1(lobo_1Id, beforeSend, onSuccess, onError)
{
    const afterSuccess = function(response)
    {
        if(response.error == null && response.result != null
            && response.result == true)                    // UNIQUE CONDITION
        {
            if(onSuccess != null)
            {
                onSuccess(response.result);
            }
        }
        else
        {
            if(onError != null)
            {
                onError(response.error);
            }
        }
    };

    $.ajax({
        url: `${apiLink}/delete_lobo_1/${lobo_1Id}`,
        method: "GET",
        dataType: "json",
        "beforeSend": function()
        {
            if(beforeSend != null)
            {
                beforeSend();
            }
        },
        success: function(response)
        {
            afterSuccess(response);
        },
        error: function(error)
        {
            if(error.status == 200 && error.statusText == "OK")
            {
                error.responseText = jQuery.parseJSON(error.responseText);

                const response = {};
                response["result"] = error.responseText.result;
                response["error"] = error.responseText.error;

                afterSuccess(response);
            }
            else
            {
                if(onError != null)
                {
                    onError(error);
                }
            }
        }
    });
}
/**
 * It gets Girafa_1s list
 * 
 * @function beforeSend - beforeSend function
 * @function onSuccess - On success function
 * @function onError - On error function
 */
export function getGirafa_1s(beforeSend, onSuccess, onError)
{
    const afterSuccess = function(response)
    {
        if(response.error == null && response.result != null)
        {
            if(onSuccess != null)
            {
                onSuccess(response.result);
            }
        }
        else
        {
            if(onError != null)
            {
                onError(response.error);
            }
        }
    };

    $.ajax({
        url: `${apiLink}/girafa_1s`,
        dataType: "json",
        "beforeSend": function()
        {
            if(beforeSend != null)
            {
                beforeSend();
            }
        },
        success: function(response)
        {
            afterSuccess(response);
        },
        error: function(error)
        {
            if(error.status == 200 && error.statusText == "OK")
            {
                error.responseText = jQuery.parseJSON(error.responseText);

                const response = {};
                response["result"] = error.responseText.result;
                response["error"] = error.responseText.error;

                afterSuccess(response);
            }
            else
            {
                if(onError != null)
                {
                    onError(error);
                }
            }
        }
    });
}

/**
 * It gets a(n) Girafa_1
 * 
 * @param {Number} girafa_1Id - Girafa_1 ID
 * @function beforeSend - beforeSend function
 * @function onSuccess - On success function
 * @function onError - On error function
 */
export function getGirafa_1(girafa_1Id, beforeSend, onSuccess, onError)
{
    const afterSuccess = function(response)
    {
        if(response.error == null && response.result != null)
        {
            if(onSuccess != null)
            {
                onSuccess(response.result);
            }
        }
        else
        {
            if(onError != null)
            {
                onError(response.error);
            }
        }
    };

    $.ajax({
        url: `${apiLink}/girafa_1/${girafa_1Id}`,
        method: "GET",
        dataType: "json",
        "beforeSend": function()
        {
            if(beforeSend != null)
            {
                beforeSend();
            }
        },
        success: function(response)
        {
            afterSuccess(response);
        },
        error: function(error)
        {
            if(error.status == 200 && error.statusText == "OK")
            {
                error.responseText = jQuery.parseJSON(error.responseText);

                const response = {};
                response["result"] = error.responseText.result;
                response["error"] = error.responseText.error;

                afterSuccess(response);
            }
            else
            {
                if(onError != null)
                {
                    onError(error);
                }
            }
        }
    });
}

/**
 * It adds a(n) Girafa_1
 * 
 * @param {Object} data - Girafa_1 data
 * @function beforeSend - beforeSend function
 * @function onSuccess - On success function
 * @function onError - On error function
 */
export function addGirafa_1(data, beforeSend, onSuccess, onError)
{
    const afterSuccess = function(response)
    {
        if(response.error == null && response.result != null 
            && response.result > 0)                 // UNIQUE CONDITION
        {
            if(onSuccess != null)
            {
                onSuccess(response.result);
            }
        }
        else
        {
            if(onError != null)
            {
                onError(response.error);
            }
        }
    };

    $.ajax({
        url: `${apiLink}/add_girafa_1`,
        dataType: "json",
        method: "POST",
        data: data,
        "beforeSend": function()
        {
            if(beforeSend != null)
            {
                beforeSend();
            }
        },
        success: function(response)
        {
            afterSuccess(response);
        },
        error: function(error)
        {
            if(error.status == 200 && error.statusText == "OK")
            {
                error.responseText = jQuery.parseJSON(error.responseText);

                const response = {};
                response["result"] = error.responseText.result;
                response["error"] = error.responseText.error;

                afterSuccess(response);
            }
            else
            {
                if(onError != null)
                {
                    onError(error);
                }
            }
        }
    });
}

/**
 * It updates a(n) Girafa_1
 * 
 * @param {Number} girafa_1Id - Girafa_1 ID
 * @param {Object} data - Girafa_1 data
 * @function beforeSend - beforeSend function
 * @function onSuccess - On success function
 * @function onError - On error function
 */
export function editGirafa_1(girafa_1Id, 
data, beforeSend, onSuccess, onError)
{
    const afterSuccess = function(response)
    {
        if(response.error == null && response.result != null
            && response.result == true)                    // UNIQUE CONDITION
        {
            if(onSuccess != null)
            {
                onSuccess(response.result);
            }
        }
        else
        {
            if(onError != null)
            {
                onError(response.error);
            }
        }
    };

    $.ajax({
        url: `${apiLink}/edit_girafa_1/${girafa_1Id}`,
        method: "POST",
        dataType: "json",
        data: data,
        "beforeSend": function()
        {
            if(beforeSend != null)
            {
                beforeSend();
            }
        },
        success: function(response)
        {
            afterSuccess(response);
        },
        error: function(error)
        {
            if(error.status == 200 && error.statusText == "OK")
            {
                error.responseText = jQuery.parseJSON(error.responseText);

                const response = {};
                response["result"] = error.responseText.result;
                response["error"] = error.responseText.error;

                afterSuccess(response);
            }
            else
            {
                if(onError != null)
                {
                    onError(error);
                }
            }
        }
    });
}
    
/**
 * It deletes a(n) Girafa_1
 * 
 * @param {Number} girafa_1Id - Girafa_1 ID
 * @function beforeSend - beforeSend function
 * @function onSuccess - On success function
 * @function onError - On error function
 */
export function deleteGirafa_1(girafa_1Id, beforeSend, onSuccess, onError)
{
    const afterSuccess = function(response)
    {
        if(response.error == null && response.result != null
            && response.result == true)                    // UNIQUE CONDITION
        {
            if(onSuccess != null)
            {
                onSuccess(response.result);
            }
        }
        else
        {
            if(onError != null)
            {
                onError(response.error);
            }
        }
    };

    $.ajax({
        url: `${apiLink}/delete_girafa_1/${girafa_1Id}`,
        method: "GET",
        dataType: "json",
        "beforeSend": function()
        {
            if(beforeSend != null)
            {
                beforeSend();
            }
        },
        success: function(response)
        {
            afterSuccess(response);
        },
        error: function(error)
        {
            if(error.status == 200 && error.statusText == "OK")
            {
                error.responseText = jQuery.parseJSON(error.responseText);

                const response = {};
                response["result"] = error.responseText.result;
                response["error"] = error.responseText.error;

                afterSuccess(response);
            }
            else
            {
                if(onError != null)
                {
                    onError(error);
                }
            }
        }
    });
}
/**
 * It gets Camelo_1s list
 * 
 * @function beforeSend - beforeSend function
 * @function onSuccess - On success function
 * @function onError - On error function
 */
export function getCamelo_1s(beforeSend, onSuccess, onError)
{
    const afterSuccess = function(response)
    {
        if(response.error == null && response.result != null)
        {
            if(onSuccess != null)
            {
                onSuccess(response.result);
            }
        }
        else
        {
            if(onError != null)
            {
                onError(response.error);
            }
        }
    };

    $.ajax({
        url: `${apiLink}/camelo_1s`,
        dataType: "json",
        "beforeSend": function()
        {
            if(beforeSend != null)
            {
                beforeSend();
            }
        },
        success: function(response)
        {
            afterSuccess(response);
        },
        error: function(error)
        {
            if(error.status == 200 && error.statusText == "OK")
            {
                error.responseText = jQuery.parseJSON(error.responseText);

                const response = {};
                response["result"] = error.responseText.result;
                response["error"] = error.responseText.error;

                afterSuccess(response);
            }
            else
            {
                if(onError != null)
                {
                    onError(error);
                }
            }
        }
    });
}

/**
 * It gets a(n) Camelo_1
 * 
 * @param {Number} camelo_1Id - Camelo_1 ID
 * @function beforeSend - beforeSend function
 * @function onSuccess - On success function
 * @function onError - On error function
 */
export function getCamelo_1(camelo_1Id, beforeSend, onSuccess, onError)
{
    const afterSuccess = function(response)
    {
        if(response.error == null && response.result != null)
        {
            if(onSuccess != null)
            {
                onSuccess(response.result);
            }
        }
        else
        {
            if(onError != null)
            {
                onError(response.error);
            }
        }
    };

    $.ajax({
        url: `${apiLink}/camelo_1/${camelo_1Id}`,
        method: "GET",
        dataType: "json",
        "beforeSend": function()
        {
            if(beforeSend != null)
            {
                beforeSend();
            }
        },
        success: function(response)
        {
            afterSuccess(response);
        },
        error: function(error)
        {
            if(error.status == 200 && error.statusText == "OK")
            {
                error.responseText = jQuery.parseJSON(error.responseText);

                const response = {};
                response["result"] = error.responseText.result;
                response["error"] = error.responseText.error;

                afterSuccess(response);
            }
            else
            {
                if(onError != null)
                {
                    onError(error);
                }
            }
        }
    });
}

/**
 * It adds a(n) Camelo_1
 * 
 * @param {Object} data - Camelo_1 data
 * @function beforeSend - beforeSend function
 * @function onSuccess - On success function
 * @function onError - On error function
 */
export function addCamelo_1(data, beforeSend, onSuccess, onError)
{
    const afterSuccess = function(response)
    {
        if(response.error == null && response.result != null 
            && response.result > 0)                 // UNIQUE CONDITION
        {
            if(onSuccess != null)
            {
                onSuccess(response.result);
            }
        }
        else
        {
            if(onError != null)
            {
                onError(response.error);
            }
        }
    };

    $.ajax({
        url: `${apiLink}/add_camelo_1`,
        dataType: "json",
        method: "POST",
        data: data,
        "beforeSend": function()
        {
            if(beforeSend != null)
            {
                beforeSend();
            }
        },
        success: function(response)
        {
            afterSuccess(response);
        },
        error: function(error)
        {
            if(error.status == 200 && error.statusText == "OK")
            {
                error.responseText = jQuery.parseJSON(error.responseText);

                const response = {};
                response["result"] = error.responseText.result;
                response["error"] = error.responseText.error;

                afterSuccess(response);
            }
            else
            {
                if(onError != null)
                {
                    onError(error);
                }
            }
        }
    });
}

/**
 * It updates a(n) Camelo_1
 * 
 * @param {Number} camelo_1Id - Camelo_1 ID
 * @param {Object} data - Camelo_1 data
 * @function beforeSend - beforeSend function
 * @function onSuccess - On success function
 * @function onError - On error function
 */
export function editCamelo_1(camelo_1Id, 
data, beforeSend, onSuccess, onError)
{
    const afterSuccess = function(response)
    {
        if(response.error == null && response.result != null
            && response.result == true)                    // UNIQUE CONDITION
        {
            if(onSuccess != null)
            {
                onSuccess(response.result);
            }
        }
        else
        {
            if(onError != null)
            {
                onError(response.error);
            }
        }
    };

    $.ajax({
        url: `${apiLink}/edit_camelo_1/${camelo_1Id}`,
        method: "POST",
        dataType: "json",
        data: data,
        "beforeSend": function()
        {
            if(beforeSend != null)
            {
                beforeSend();
            }
        },
        success: function(response)
        {
            afterSuccess(response);
        },
        error: function(error)
        {
            if(error.status == 200 && error.statusText == "OK")
            {
                error.responseText = jQuery.parseJSON(error.responseText);

                const response = {};
                response["result"] = error.responseText.result;
                response["error"] = error.responseText.error;

                afterSuccess(response);
            }
            else
            {
                if(onError != null)
                {
                    onError(error);
                }
            }
        }
    });
}
    
/**
 * It deletes a(n) Camelo_1
 * 
 * @param {Number} camelo_1Id - Camelo_1 ID
 * @function beforeSend - beforeSend function
 * @function onSuccess - On success function
 * @function onError - On error function
 */
export function deleteCamelo_1(camelo_1Id, beforeSend, onSuccess, onError)
{
    const afterSuccess = function(response)
    {
        if(response.error == null && response.result != null
            && response.result == true)                    // UNIQUE CONDITION
        {
            if(onSuccess != null)
            {
                onSuccess(response.result);
            }
        }
        else
        {
            if(onError != null)
            {
                onError(response.error);
            }
        }
    };

    $.ajax({
        url: `${apiLink}/delete_camelo_1/${camelo_1Id}`,
        method: "GET",
        dataType: "json",
        "beforeSend": function()
        {
            if(beforeSend != null)
            {
                beforeSend();
            }
        },
        success: function(response)
        {
            afterSuccess(response);
        },
        error: function(error)
        {
            if(error.status == 200 && error.statusText == "OK")
            {
                error.responseText = jQuery.parseJSON(error.responseText);

                const response = {};
                response["result"] = error.responseText.result;
                response["error"] = error.responseText.error;

                afterSuccess(response);
            }
            else
            {
                if(onError != null)
                {
                    onError(error);
                }
            }
        }
    });
}
/**
 * It gets Jacare_1s list
 * 
 * @function beforeSend - beforeSend function
 * @function onSuccess - On success function
 * @function onError - On error function
 */
export function getJacare_1s(beforeSend, onSuccess, onError)
{
    const afterSuccess = function(response)
    {
        if(response.error == null && response.result != null)
        {
            if(onSuccess != null)
            {
                onSuccess(response.result);
            }
        }
        else
        {
            if(onError != null)
            {
                onError(response.error);
            }
        }
    };

    $.ajax({
        url: `${apiLink}/jacare_1s`,
        dataType: "json",
        "beforeSend": function()
        {
            if(beforeSend != null)
            {
                beforeSend();
            }
        },
        success: function(response)
        {
            afterSuccess(response);
        },
        error: function(error)
        {
            if(error.status == 200 && error.statusText == "OK")
            {
                error.responseText = jQuery.parseJSON(error.responseText);

                const response = {};
                response["result"] = error.responseText.result;
                response["error"] = error.responseText.error;

                afterSuccess(response);
            }
            else
            {
                if(onError != null)
                {
                    onError(error);
                }
            }
        }
    });
}

/**
 * It gets a(n) Jacare_1
 * 
 * @param {Number} jacare_1Id - Jacare_1 ID
 * @function beforeSend - beforeSend function
 * @function onSuccess - On success function
 * @function onError - On error function
 */
export function getJacare_1(jacare_1Id, beforeSend, onSuccess, onError)
{
    const afterSuccess = function(response)
    {
        if(response.error == null && response.result != null)
        {
            if(onSuccess != null)
            {
                onSuccess(response.result);
            }
        }
        else
        {
            if(onError != null)
            {
                onError(response.error);
            }
        }
    };

    $.ajax({
        url: `${apiLink}/jacare_1/${jacare_1Id}`,
        method: "GET",
        dataType: "json",
        "beforeSend": function()
        {
            if(beforeSend != null)
            {
                beforeSend();
            }
        },
        success: function(response)
        {
            afterSuccess(response);
        },
        error: function(error)
        {
            if(error.status == 200 && error.statusText == "OK")
            {
                error.responseText = jQuery.parseJSON(error.responseText);

                const response = {};
                response["result"] = error.responseText.result;
                response["error"] = error.responseText.error;

                afterSuccess(response);
            }
            else
            {
                if(onError != null)
                {
                    onError(error);
                }
            }
        }
    });
}

/**
 * It adds a(n) Jacare_1
 * 
 * @param {Object} data - Jacare_1 data
 * @function beforeSend - beforeSend function
 * @function onSuccess - On success function
 * @function onError - On error function
 */
export function addJacare_1(data, beforeSend, onSuccess, onError)
{
    const afterSuccess = function(response)
    {
        if(response.error == null && response.result != null 
            && response.result > 0)                 // UNIQUE CONDITION
        {
            if(onSuccess != null)
            {
                onSuccess(response.result);
            }
        }
        else
        {
            if(onError != null)
            {
                onError(response.error);
            }
        }
    };

    $.ajax({
        url: `${apiLink}/add_jacare_1`,
        dataType: "json",
        method: "POST",
        data: data,
        "beforeSend": function()
        {
            if(beforeSend != null)
            {
                beforeSend();
            }
        },
        success: function(response)
        {
            afterSuccess(response);
        },
        error: function(error)
        {
            if(error.status == 200 && error.statusText == "OK")
            {
                error.responseText = jQuery.parseJSON(error.responseText);

                const response = {};
                response["result"] = error.responseText.result;
                response["error"] = error.responseText.error;

                afterSuccess(response);
            }
            else
            {
                if(onError != null)
                {
                    onError(error);
                }
            }
        }
    });
}

/**
 * It updates a(n) Jacare_1
 * 
 * @param {Number} jacare_1Id - Jacare_1 ID
 * @param {Object} data - Jacare_1 data
 * @function beforeSend - beforeSend function
 * @function onSuccess - On success function
 * @function onError - On error function
 */
export function editJacare_1(jacare_1Id, 
data, beforeSend, onSuccess, onError)
{
    const afterSuccess = function(response)
    {
        if(response.error == null && response.result != null
            && response.result == true)                    // UNIQUE CONDITION
        {
            if(onSuccess != null)
            {
                onSuccess(response.result);
            }
        }
        else
        {
            if(onError != null)
            {
                onError(response.error);
            }
        }
    };

    $.ajax({
        url: `${apiLink}/edit_jacare_1/${jacare_1Id}`,
        method: "POST",
        dataType: "json",
        data: data,
        "beforeSend": function()
        {
            if(beforeSend != null)
            {
                beforeSend();
            }
        },
        success: function(response)
        {
            afterSuccess(response);
        },
        error: function(error)
        {
            if(error.status == 200 && error.statusText == "OK")
            {
                error.responseText = jQuery.parseJSON(error.responseText);

                const response = {};
                response["result"] = error.responseText.result;
                response["error"] = error.responseText.error;

                afterSuccess(response);
            }
            else
            {
                if(onError != null)
                {
                    onError(error);
                }
            }
        }
    });
}
    
/**
 * It deletes a(n) Jacare_1
 * 
 * @param {Number} jacare_1Id - Jacare_1 ID
 * @function beforeSend - beforeSend function
 * @function onSuccess - On success function
 * @function onError - On error function
 */
export function deleteJacare_1(jacare_1Id, beforeSend, onSuccess, onError)
{
    const afterSuccess = function(response)
    {
        if(response.error == null && response.result != null
            && response.result == true)                    // UNIQUE CONDITION
        {
            if(onSuccess != null)
            {
                onSuccess(response.result);
            }
        }
        else
        {
            if(onError != null)
            {
                onError(response.error);
            }
        }
    };

    $.ajax({
        url: `${apiLink}/delete_jacare_1/${jacare_1Id}`,
        method: "GET",
        dataType: "json",
        "beforeSend": function()
        {
            if(beforeSend != null)
            {
                beforeSend();
            }
        },
        success: function(response)
        {
            afterSuccess(response);
        },
        error: function(error)
        {
            if(error.status == 200 && error.statusText == "OK")
            {
                error.responseText = jQuery.parseJSON(error.responseText);

                const response = {};
                response["result"] = error.responseText.result;
                response["error"] = error.responseText.error;

                afterSuccess(response);
            }
            else
            {
                if(onError != null)
                {
                    onError(error);
                }
            }
        }
    });
}