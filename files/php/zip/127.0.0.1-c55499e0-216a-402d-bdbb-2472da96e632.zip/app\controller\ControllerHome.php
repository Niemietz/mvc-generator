<?php

namespace App\Controller;
    
use Src\Classes\Render;
    
class ControllerHome extends Render
{
    public function __construct()
    {
        parent::__construct();

        $this->setTitle("GARRUNCHERA");
        $this->setDescription("");
        $this->setKeywords(array(
        ));
        $this->setDirectory("home");

        $this->renderLayout();
    }
}
