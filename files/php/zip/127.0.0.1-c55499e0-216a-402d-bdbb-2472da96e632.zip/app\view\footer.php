<div class="row">
    <div class="col-12 col-sm-12 col-md-12 col-lg-12">
        Copyright © <?php echo date('Y'); ?> Developed by ™. All rights reserved.
    </div>
</d