<?php
namespace App\Model;

use App\Model\SuperClass\eModel;

use App\DataDAO;

class Garruncho extends eModel
{
    private $tipo;
    
    function __construct()
    {
        parent::__construct();
        $this->tipo = -1;
    }

    public function read()
    {
        $result = false;

        $query = "SELECT ";
        $query .= "g.tipo";
        $query .= " FROM garrunchos g";
        $query .= " WHERE g.id = " . $this->getId();

        $dao = new DAO();
        $sql = $dao->executeQuery($query);

        if(mysqli_num_rows($sql) > 0)
        {
            if($row = $sql->fetch_assoc())
            {
                $this->setId($row['id']);
                $this->setTipo($row['tipo']);
            }

            $result = true;
        }

        return $result;
    }

    public function insert()
    {
        $result = 0;

        $query = "SELECT g.id";
        $query .= " FROM garrunchos g";
        $query .= " WHERE g.tipo = " . $this->getTipo();
        
        $dao = new DAO();
        $sql = $dao->executeQuery($query);

        if(mysqli_num_rows($sql) == 0)
        {
            $query = "INSERT INTO garrunchos(";
            $query .= "tipo";
            $query .= ")";
            $query .= " VALUES (";
            $query .= $this->getTipo() . ", ";
            $query .= 
            $query .= ")";

            $garrunchoId = $dao->executeQueryAndGetId($query);

            if($garrunchoId > 0)
            {
                $this->setId($garrunchoId);
                $result = $garrunchoId;
            }
        }
        else
        {
            if($row = $sql->fetch_assoc())
            {
                $this->setId((int)$row["id"]);
                $result = (int)$row["id"];
            }
        }

        return $result;
    }

    public function update()
    {
        $result = false;

        if($this->getId() > 0)
        {
            $query = "UPDATE garrunchos SET ";
            $query .= "tipo = " . $this->getTipo() . ", ";
            $query .= "
            $query .= " WHERE id = " . $this->getId();

            $dao = new DAO();
            if($dao->executeQueryAndGetNumberOfAffectedRows($query) > 0)
            {
                $result = true;
            }
        }

        return $result;
    }

    public function delete()
    {
        $result = false;

        if($this->getId() > 0)
        {
            $query = "DELETE FROM garrunchos";
            $query .= " WHERE id = " . $this->getId();

            try
            {
                $dao = new DAO();
                if($dao->executeQueryAndGetNumberOfAffectedRows($query))
                {
                    $result = true;
                }
            }
            catch(Exception $error)
            {
                throw $error;
            }
        }
        else
        {
            throw new \Exception("Could not delete Garruncho from database: Missing ID.");
        }

        return $result;
    }

    public function getTipo()
    {
        return $this->tipo;
    }

    public function setTipo($tipo)
    {
        $this->tipo = $tipo;
    }

    public function jsonSerialize()
    {
        return array(
            'id' => $this->getId(),
            'tipo' => $this->getTipo()
        );
    }
}