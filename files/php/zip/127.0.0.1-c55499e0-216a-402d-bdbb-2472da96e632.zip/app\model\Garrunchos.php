<?php
namespace App\Model;

use App\Model\SuperClass\eModelList;
use App\Model\Garruncho;
use App\Data\DAO;

class Garrunchos extends eModelList
{
    public function read()
    {
        $result = false;

        $query = "SELECT g.id, ";
        $query .= "g.tipo";
        $query .= " FROM garrunchos g";

        try
        {
            $dao = new DAO();
            $sql = $dao->executeQuery($query);

            if(mysqli_num_rows($sql) > 0)
            {
                while($row = $sql->fetch_array())
                {
                    $garruncho = new Garruncho();
                    $garruncho->setId($row['id']);
                    $garruncho->setTipo($row['tipo']);

                    $this->add($garruncho);
                }

                $result = true;
            }
        }
        catch(\Exception $error)
        {
            throw $error;
        }

        return $result;
    }
}