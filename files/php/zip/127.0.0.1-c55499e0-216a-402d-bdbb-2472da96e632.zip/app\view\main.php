<!DOCTYPE html>
<html lang="pt-br">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="author" content="">
        <meta name="description" content="<?php echo $this->getDescription(); ?>">
        <meta name="keywords" content="<?php echo $this->getKeywords(); ?>">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <title><?php echo $this->getTitle(); ?></title>

        <link rel="shortcut icon" sizes="16x16" href="<?= DIRFAVICON . "/16x16/favicon.ico" . (USECACHE) ? "" : "?v=" . md5(time()); ?>" />
        <link rel="shortcut icon" sizes="16x16" type="image/png" href="<?= DIRFAVICON . "/16x16/favicon.png" . (USECACHE) ? "" : "?v=" . md5(time()); ?>">
        <link rel="icon" sizes="16x16" type="image/vnd.microsoft.icon" href="<?= DIRFAVICON . "/16x16/favicon.ico" . (USECACHE) ? "" : "?v=" . md5(time()); ?>">
        <link rel="icon" sizes="16x16" type="image/x-icon" href="/<?= DIRFAVICON . "/16x16/favicon.ico" . (USECACHE) ? "" : "?v=" . md5(time()); ?>">
        <link rel="icon" sizes="16x16" href="<?= DIRFAVICON . "/16x16/favicon.ico" . (USECACHE) ? "" : "?v=" . md5(time()); ?>" />
        <link rel="icon" sizes="16x16" type="image/png" href="<?= DIRFAVICON . "/16x16/favicon.png" . (USECACHE) ? "" : "?v=" . md5(time()); ?>">

        <link rel="shortcut icon" sizes="32x32" href="<?= DIRFAVICON . "/32x32/favicon.ico" . (USECACHE) ? "" : "?v=" . md5(time()); ?>" />
        <link rel="shortcut icon" sizes="32x32" type="image/png" href="<?= DIRFAVICON . "/32x32/favicon.png" . (USECACHE) ? "" : "?v=" . md5(time()); ?>">
        <link rel="icon" sizes="32x32" type="image/vnd.microsoft.icon" href="<?= DIRFAVICON . "/32x32/favicon.ico" . (USECACHE) ? "" : "?v=" . md5(time()); ?>">
        <link rel="icon" sizes="32x32" type="image/x-icon" href="/<?= DIRFAVICON . "/32x32/favicon.ico" . (USECACHE) ? "" : "?v=" . md5(time()); ?>">
        <link rel="icon" sizes="32x32" href="<?= DIRFAVICON . "/32x32/favicon.ico" . (USECACHE) ? "" : "?v=" . md5(time()); ?>" />
        <link rel="icon" sizes="32x32" type="image/png" href="<?= DIRFAVICON . "/32x32/favicon.png" . (USECACHE) ? "" : "?v=" . md5(time()); ?>">

        <link rel="shortcut icon" sizes="64x64" href="<?= DIRFAVICON . "/64x64/favicon.ico" . (USECACHE) ? "" : "?v=" . md5(time()); ?>" />
        <link rel="shortcut icon" sizes="64x64" type="image/png" href="<?= DIRFAVICON . "/64x64/favicon.png" . (USECACHE) ? "" : "?v=" . md5(time()); ?>">
        <link rel="icon" sizes="64x64" type="image/vnd.microsoft.icon" href="<?= DIRFAVICON . "/64x64/favicon.ico" . (USECACHE) ? "" : "?v=" . md5(time()); ?>">
        <link rel="icon" sizes="64x64" type="image/x-icon" href="/<?= DIRFAVICON . "/64x64/favicon.ico" . (USECACHE) ? "" : "?v=" . md5(time()); ?>">
        <link rel="icon" sizes="64x64" href="<?= DIRFAVICON . "/64x64/favicon.ico" . (USECACHE) ? "" : "?v=" . md5(time()); ?>" />
        <link rel="icon" sizes="64x64" type="image/png" href="<?= DIRFAVICON . "/64x64/favicon.png" . (USECACHE) ? "" : "?v=" . md5(time()); ?>">

        <link rel="shortcut icon" sizes="96x96" type="image/png" href="<?= DIRFAVICON . "/96x96/favicon.png" . (USECACHE) ? "" : "?v=" . md5(time()); ?>">
        <link rel="icon" sizes="96x96" type="image/vnd.microsoft.icon" href="<?= DIRFAVICON . "/96x96/favicon.png" . (USECACHE) ? "" : "?v=" . md5(time()); ?>">
        <link rel="icon" sizes="96x96" type="image/x-icon" href="/<?= DIRFAVICON . "/96x96/favicon.png" . (USECACHE) ? "" : "?v=" . md5(time()); ?>">
        <link rel="icon" sizes="96x96" href="<?= DIRFAVICON . "/96x96/favicon.png" . (USECACHE) ? "" : "?v=" . md5(time()); ?>" />
        <link rel="icon" sizes="96x96" type="image/png" href="<?= DIRFAVICON . "/96x96/favicon.png" . (USECACHE) ? "" : "?v=" . md5(time()); ?>">

        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/material-components-web/4.0.0/material-components-web.min.css">
        <link rel="stylesheet" href="https://cdn.datatables.net/1.10.23/css/dataTables.material.min.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.2/css/all.min.css">
        <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700&display=swap" />
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/3.2.0/mdb.min.css">
        <link rel="stylesheet" href="<?= DIRCSS . '/bootstrap-multiselect.min.css' ?>">
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@10.14.0/dist/sweetalert2.min.css">
        <link rel="stylesheet" href="<?= DIRCSS . '/notiflix-2.7.0.min.css' ?>">

        <link rel="stylesheet" href="<?= DIRCSS . '/custom.css' ?>">
        <?php echo $this->addHead(); ?>
    </head>
    <body>

        <script type="text/javascript" src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
        <script type="text/javascript" src="https://cdn.datatables.net/1.10.23/js/jquery.dataTables.min.js"></script>
        <script type="text/javascript" src="https://cdn.datatables.net/1.10.23/js/dataTables.material.min.js"></script>
        <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/3.2.0/mdb.min.js"></script>
        <script type="text/javascript" src="<?= DIRJS . "/bootstrap-multiselect.min.js" ?>"></script>
        <script type="text/javascript" src="https://cdn.jsdelivr.net/gh/xcash/bootstrap-autocomplete@v2.3.7/dist/latest/bootstrap-autocomplete.min.js"></script>
        <script type="text/javascript" src="https://cdn.jsdelivr.net/npm/sweetalert2@10.14.0/dist/sweetalert2.min.js"></script>
        <script type="text/javascript" src="<?= DIRJS . "/notiflix-aio-2.7.0.min.js" ?>"></script>

        <script type="text/javascript" src="<?= DIRJS . '/commons.js' ?>"></script>
        <script type="text/javascript" src="<?= DIRJS . '/index.js' ?>"></script>

        <div class="Header">
            <?php echo $this->addHeader(); ?>
        </div>

        <div class="Content">
            <?php echo $this->addContent(); ?>
        </div>

        <div class="Footer">
            <?php echo $this->addFooter(); ?>
        </div>

        <div class="Modals">
            <?php
                $this->addModals();
            ?>
        </div>
    </body>
</html>