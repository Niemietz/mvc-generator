import { addGarruncho, editGarruncho } from './../api.js';

const garrunchoIdAttribute = "garrunchoId";
const frmGarrunchoId = "form-garruncho";
const btnEditId = "edit-garruncho";
const btnAddId = "add-garruncho";

function treatFormData(data) {
    data["tipo"] = parseInt(data["tipo"])
    return data
}

document.addEventListener(contentLoadedEventListener, function(event) {
    document.getElementById(btnEditId).onclick = function(evt) {
        const garrunchoId = this.getAttribute(garrunchoIdAttribute);

        const form = document.getElementById(frmGarrunchoId);

        let data = form.serializeFormJSON();

        data = treatFormData(data);

        editGarruncho(
            garrunchoId,
            data,
            function() {
                setLoading(true);
            }, function(result) {
                if (result) {
                    showMessage("O/A Garruncho foi atualizado!", 1);
                } else {
                    showMessage("Algo deu errado!", 2);
                }
                setLoading(false);
            }, function(error) {
                showMessage("Algo deu errado!", 2);
                //console.error(error);
                setLoading(false);
            }
        )
    };

    document.getElementById(btnAddId).onclick = function(evt) {
        const form = document.getElementById(frmGarrunchoId);

        let data = form.serializeFormJSON();

        data = treatFormData(data);

        addGarruncho(
            data,
            function() {
                setLoading(true);
            }, function(result) {
                if (result) {
                    showMessage("O/A Garruncho foi atualizado!", 1);
                } else {
                    showMessage("Algo deu errado!", 2);
                }
                setLoading(false);
            }, function(error) {
                showMessage("Algo deu errado!", 2);
                //console.error(error);
                setLoading(false);
            }
        )
    };
});