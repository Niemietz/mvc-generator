<?php
namespace App\Controller;

use App\Model\Garruncho;
use App\Model\Garrunchos;
use App\Data\DAO;
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require DIRREQ . '/src/vendor/autoload.php';

class ControllerAPI extends eController
{
    public function __construct()
    {
        parent::__construct();

        header('Content-Type: application/json');
    }

    public function garrunchos()
    {
        try
        {
            $garrunchos = new Garrunchos();
            $garrunchos->read();
    
            $this->result["result"] = $garrunchos->getList();
            $this->result["error"] = null;
        }
        catch(\Exception $ex)
        {
            $this->result["result"] = null;
            $this->result["error"] = $ex->getMessage();
        }
    
        print_r(json_encode($this->result));
    }
    
    public function garruncho($garrunchoId)
    {
        try
        {
            $garruncho = new Garruncho();
            $garruncho->setId($garrunchoId);
            $garruncho->read();
    
            $this->result["result"] = $garruncho;
            $this->result["error"] = null;
        }
        catch(\Exception $ex)
        {
            $this->result["result"] = null;
            $this->result["error"] = $ex->getMessage();
        }
    
        print_r(json_encode($this->result));
    }
    
    public function add_garruncho()
    {
        $dao = null;
        try
        {
            $garruncho = new Garruncho();
            if(!is_null($_POST["tipo"]) && isset($_POST["tipo"]))
            {
                $garruncho->setTipo($_POST["tipo"]);
            }
            $dao = new DAO();
            $dao->startTransaction();
    
            $garrunchoId =$garruncho->insert();

            if($garrunchoId > 0)
            {
                $dao->commitTransaction();

                $this->result["result"] = $garrunchoId;
                $this->result["error"] = null;
            }
            else
            {
                if (!is_null($dao))
            {
                $dao->rollbackTransaction();
            }
            }
        }
        catch(\Exception $ex)
        {
            if (!is_null($dao))
            {
                $dao->rollbackTransaction();
            }

            $this->result["result"] = null;
            $this->result["error"] = $ex->getMessage();
        }

        print_r(json_encode($this->result));
    }

    public function edit_garruncho($garrunchoId)
    {
        $dao = null;
        try
        {
            $garruncho = new Garruncho();
            $garruncho->read($garrunchoId);
    
            if(!is_null($_POST["tipo"]) && isset($_POST["tipo"]))
            {
                $garruncho->setTipo($_POST["tipo"]);
            }
            
            $dao = new DAO();
            $dao->startTransaction();
    
            if($garruncho->update() == true)
            {
                $dao->commitTransaction();
    
                $this->result["result"] = true;
                $this->result["error"] = null;
            }
            else
            {
                if (!is_null($dao))
            {
                $dao->rollbackTransaction();
            }
            }
        }
        catch(\Exception $ex)
        {
            if (!is_null($dao))
            {
                $dao->rollbackTransaction();
            }
    
            $this->result["result"] = null;
            $this->result["error"] = $ex->getMessage();
        }
    
        print_r(json_encode($this->result));
    }
    
    public function delete_garruncho($garrunchoId)
    {
        $dao = null;
        try
        {
            $garruncho = new Garruncho();
            $garruncho->read($garrunchoId);
    
            $dao = new DAO();
            $dao->startTransaction();
    
            if($garruncho->delete() == true)
            {
                $dao->commitTransaction();
    
                $this->result["result"] = true;
                $this->result["error"] = null;
            }
            else
            {
                if (!is_null($dao))
            {
                $dao->rollbackTransaction();
            }

                $this->result["result"] = false;
                $this->result["error"] = "Could not delete Garruncho!";
            }
        }
        catch(\Exception $ex)
        {
            if (!is_null($dao))
            {
                $dao->rollbackTransaction();
            }
    
            $this->result["result"] = null;
            $this->result["error"] = $ex->getMessage();
        }
    
        print_r(json_encode($this->result));
    }
}