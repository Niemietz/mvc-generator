<?php
namespace Src\Classes;

use Src\Interfaces\iView;

class Render implements iView
{
    private $directory;
    private $title;
    private $description;
    private $keywords;
    
    public function __construct()
    {
        $this->keywords = array(
            ""
        );
    }
    
    public function getDirectory()
    {
        return $this->directory;
    }
    
    public function setDirectory($directory)
    {
        $this->directory = $directory;
    }
    
    public function getTitle()
    {
        return $this->title;
    }
    
    public function setTitle($title)
    {
        $this->title = $title;
    }

    public function getDescription()
    {
        return $this->description;
    }
    
    public function setDescription($description)
    {
        $this->description = $description;
    }

    public function getKeywords()
    {
        $keywordsString = "";
        $i = 0;
        foreach($this->keywords as $keyword)
        {
            if($i > 0)
            {
                $keywordsString .= ", ";                
            }
            $keywordsString .= $keyword;
            $i++;
        }

        return $keywordsString;
    }

    public function setKeywords($keywords)
    {
        $newKeywords = array_merge($this->keywords, $keywords);

        $this->keywords = $newKeywords;
    }

    public function renderLayout()
    {
        include_once(DIRREQ . "app/view/main.php");
    }
    
    public function addHead()
    {
        if(file_exists(DIRREQ . "app/view/{$this->getDirectory()}/head.php"))
        {
            include(DIRREQ . "app/view/{$this->getDirectory()}/head.php");
        }
    }
    
    public function addTopbar()
    {
        if(file_exists(DIRREQ . "app/view/topbar.php"))
        {
            include(DIRREQ . "app/view/topbar.php");
        }
    }

    public function addHeader()
    {
        if(file_exists(DIRREQ . "app/view/{$this->getDirectory()}/header.php"))
        {
            include(DIRREQ . "app/view/{$this->getDirectory()}/header.php");
        }
    }
    
    public function addContent()
    {
        if(file_exists(DIRREQ . "app/view/{$this->getDirectory()}/content.php"))
        {
            include(DIRREQ . "app/view/{$this->getDirectory()}/content.php");
        }        
    }

    public function addFooter()
    {
        if(file_exists(DIRREQ . "app/view/{$this->getDirectory()}/footer.php"))
        {
            include(DIRREQ . "app/view/{$this->getDirectory()}/footer.php");
        }
    }

    public function addModals()
    {
        $this->addEditGarrunchoModal();
   }

    private function addEditGarrunchoModal()
    {
        if(file_exists(DIRREQ . "app/view/Garrunchos/modals/addEdit_garruncho_modal.php"))
        {
            include(DIRREQ . "app/view/Garrunchos/modals/addEdit_garruncho_modal.php");
        }
    }
}