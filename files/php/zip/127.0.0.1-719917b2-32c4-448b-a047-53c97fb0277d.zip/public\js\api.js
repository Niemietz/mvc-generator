const apiLink = "/api";

/**
 * It gets Garrunchos list
 * 
 * @function beforeSend - beforeSend function
 * @function onSuccess - On success function
 * @function onError - On error function
 */
export function getGarrunchos(beforeSend, onSuccess, onError)
{
    const afterSuccess = function(response)
    {
        if(response.error == null && response.result != null)
        {
            if(onSuccess != null)
            {
                onSuccess(response.result);
            }
        }
        else
        {
            if(onError != null)
            {
                onError(response.error);
            }
        }
    };

    $.ajax({
        url: `${apiLink}/garrunchos`,
        dataType: "json",
        "beforeSend": function()
        {
            if(beforeSend != null)
            {
                beforeSend();
            }
        },
        success: function(response)
        {
            afterSuccess(response);
        },
        error: function(error)
        {
            if(error.status == 200 && error.statusText == "OK")
            {
                error.responseText = jQuery.parseJSON(error.responseText);

                const response = {};
                response["result"] = error.responseText.result;
                response["error"] = error.responseText.error;

                afterSuccess(response);
            }
            else
            {
                if(onError != null)
                {
                    onError(error);
                }
            }
        }
    });
}

/**
 * It gets a(n) Garruncho
 * 
 * @param {Number} garrunchoId - Garruncho ID
 * @function beforeSend - beforeSend function
 * @function onSuccess - On success function
 * @function onError - On error function
 */
export function getGarruncho(garrunchoId, beforeSend, onSuccess, onError)
{
    const afterSuccess = function(response)
    {
        if(response.error == null && response.result != null)
        {
            if(onSuccess != null)
            {
                onSuccess(response.result);
            }
        }
        else
        {
            if(onError != null)
            {
                onError(response.error);
            }
        }
    };

    $.ajax({
        url: `${apiLink}/garruncho/${garrunchoId}`,
        method: "GET",
        dataType: "json",
        "beforeSend": function()
        {
            if(beforeSend != null)
            {
                beforeSend();
            }
        },
        success: function(response)
        {
            afterSuccess(response);
        },
        error: function(error)
        {
            if(error.status == 200 && error.statusText == "OK")
            {
                error.responseText = jQuery.parseJSON(error.responseText);

                const response = {};
                response["result"] = error.responseText.result;
                response["error"] = error.responseText.error;

                afterSuccess(response);
            }
            else
            {
                if(onError != null)
                {
                    onError(error);
                }
            }
        }
    });
}

/**
 * It adds a(n) Garruncho
 * 
 * @param {Object} data - Garruncho data
 * @function beforeSend - beforeSend function
 * @function onSuccess - On success function
 * @function onError - On error function
 */
export function addGarruncho(data, beforeSend, onSuccess, onError)
{
    const afterSuccess = function(response)
    {
        if(response.error == null && response.result != null 
            && response.result > 0)                 // UNIQUE CONDITION
        {
            if(onSuccess != null)
            {
                onSuccess(response.result);
            }
        }
        else
        {
            if(onError != null)
            {
                onError(response.error);
            }
        }
    };

    $.ajax({
        url: `${apiLink}/add_garruncho`,
        dataType: "json",
        method: "POST",
        data: data,
        "beforeSend": function()
        {
            if(beforeSend != null)
            {
                beforeSend();
            }
        },
        success: function(response)
        {
            afterSuccess(response);
        },
        error: function(error)
        {
            if(error.status == 200 && error.statusText == "OK")
            {
                error.responseText = jQuery.parseJSON(error.responseText);

                const response = {};
                response["result"] = error.responseText.result;
                response["error"] = error.responseText.error;

                afterSuccess(response);
            }
            else
            {
                if(onError != null)
                {
                    onError(error);
                }
            }
        }
    });
}

/**
 * It updates a(n) Garruncho
 * 
 * @param {Number} garrunchoId - Garruncho ID
 * @param {Object} data - Garruncho data
 * @function beforeSend - beforeSend function
 * @function onSuccess - On success function
 * @function onError - On error function
 */
export function editGarruncho(garrunchoId, 
data, beforeSend, onSuccess, onError)
{
    const afterSuccess = function(response)
    {
        if(response.error == null && response.result != null
            && response.result == true)                    // UNIQUE CONDITION
        {
            if(onSuccess != null)
            {
                onSuccess(response.result);
            }
        }
        else
        {
            if(onError != null)
            {
                onError(response.error);
            }
        }
    };

    $.ajax({
        url: `${apiLink}/edit_garruncho/${garrunchoId}`,
        method: "POST",
        dataType: "json",
        data: data,
        "beforeSend": function()
        {
            if(beforeSend != null)
            {
                beforeSend();
            }
        },
        success: function(response)
        {
            afterSuccess(response);
        },
        error: function(error)
        {
            if(error.status == 200 && error.statusText == "OK")
            {
                error.responseText = jQuery.parseJSON(error.responseText);

                const response = {};
                response["result"] = error.responseText.result;
                response["error"] = error.responseText.error;

                afterSuccess(response);
            }
            else
            {
                if(onError != null)
                {
                    onError(error);
                }
            }
        }
    });
}
    
/**
 * It deletes a(n) Garruncho
 * 
 * @param {Number} garrunchoId - Garruncho ID
 * @function beforeSend - beforeSend function
 * @function onSuccess - On success function
 * @function onError - On error function
 */
export function deleteGarruncho(garrunchoId, beforeSend, onSuccess, onError)
{
    const afterSuccess = function(response)
    {
        if(response.error == null && response.result != null
            && response.result == true)                    // UNIQUE CONDITION
        {
            if(onSuccess != null)
            {
                onSuccess(response.result);
            }
        }
        else
        {
            if(onError != null)
            {
                onError(response.error);
            }
        }
    };

    $.ajax({
        url: `${apiLink}/delete_garruncho/${garrunchoId}`,
        method: "GET",
        dataType: "json",
        "beforeSend": function()
        {
            if(beforeSend != null)
            {
                beforeSend();
            }
        },
        success: function(response)
        {
            afterSuccess(response);
        },
        error: function(error)
        {
            if(error.status == 200 && error.statusText == "OK")
            {
                error.responseText = jQuery.parseJSON(error.responseText);

                const response = {};
                response["result"] = error.responseText.result;
                response["error"] = error.responseText.error;

                afterSuccess(response);
            }
            else
            {
                if(onError != null)
                {
                    onError(error);
                }
            }
        }
    });
}