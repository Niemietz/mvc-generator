import { addGarruncho, editGarruncho, getGarruncho, getGarrunchos } from './../api.js';

const garrunchoIdAttribute = "garrunchoId"
const labGarrunchoTitleId = "add-edit-garruncho-title"
const mdlGarrunchoId = "mdl-add-edit-garruncho"
const frmGarrunchoId = "form-garruncho";
const divContainerGarrunchosId = "container-garrunchos";
const divNoGarrunchosId = "no-garrunchos";
const btnAddEditId = "add-edit-garruncho";
const inpTipoId = "tipo";

function getEditButtonHTML() {
    const button = document.createElement("button");
    button.type = "button";
    button.setAttribute("data-mdb-toggle", "modal")
    button.setAttribute("data-mdb-target", `#${mdlGarrunchoId}`)
    button.setAttribute("editing", "true")
    button.classList.add("btn");
    button.classList.add("btn-warning");
    button.innerHTML = "Atualizar";

    return button
}

function treatFormData(data) {
data["tipo"] = parseInt(data["tipo"])
    
    return data
}

function getGarrunchosAndLoad() {
    getGarrunchos(
        function() {
            setLoading(true);
        }, function(garrunchos) {
            if (garrunchos.length > 0) {
                loadTable(garrunchos);

                document.getElementById(divContainerGarrunchosId).classList.remove("d-none");
                document.getElementById(divNoGarrunchosId).classList.add("d-none");
            } else {
                document.getElementById(divContainerGarrunchosId).classList.add("d-none");
                document.getElementById(divNoGarrunchosId).classList.remove("d-none");
                showMessage("Algo deu errado!", 2);
            }
            setLoading(false);
        }, function(error) {
            document.getElementById(divContainerGarrunchosId).classList.add("d-none");
            document.getElementById(divNoGarrunchosId).classList.remove("d-none");
            showMessage("Algo deu errado!", 2);
            //console.error(error);
            setLoading(false);
        }
    )
}

function loadTable(garrunchos) {
    garrunchos.forEach((garruncho) => {
        garruncho.push(getEditButtonHTML())
    });

    $(`#${tblGarrunchoId}`).DataTable({
        data: garrunchos, // TODO Deve estar assim: [ [ 1, "ModelA" ], [ 2, "ModelB" ] ]
        columns: [
            { title: "Id" },
            { title: "Nome" },
            { title: "#" }
        ],
        autoWidth: false,
        columnDefs: [{
            targets: ['_all'],
            className: 'mdc-data-table__cell'
        }]
    });
}

document.addEventListener(contentLoadedEventListener, function(event) {
    document.getElementById(divContainerGarrunchosId).classList.add("d-none");
    document.getElementById(divNoGarrunchosId).classList.remove("d-none");

    const modalEl = document.getElementById(mdlGarrunchoId);
    const modal = new mdb.Modal(modalEl);

    getGarrunchosAndLoad();

    modalEl.addEventListener('show.mdb.modal', (event) => {
        /*if (event.target.related.getAttribute("editing") == "true") {   // TODO Review
            const garrunchoId = -1; // TODO Review (Pegar da coluna da tabela)
            document.getElementById(btnAddEditId).setAttribute(garrunchoIdAttribute, garrunchoId)
            document.getElementById(btnAddEditId).innerHTML = "Atualizar"
            document.getElementById(labGarrunchoTitleId).innerHTML = "Atualizar Garruncho"

            getGarruncho(garrunchoId,
                function() {
                    setLoading(true);
                    //setLoadingModal(true, document.getElementById(mdlGarrunchoId)); // TODO Review
                },
                function(garruncho) {
    
                    document.getElementById(inpTipoId).value = garruncho.tipo
    
                    //setLoadingModal(false, document.getElementById(mdlGarrunchoId)); // TODO Review
                    setLoading(false);
                },
                function(error) {
                    //setLoadingModal(false, document.getElementById(mdlGarrunchoId)); // TODO Review
                    modal.hide();
                    showMessage("Algo deu errado!", 2);
                    //console.error(error);
                    setLoading(false);
                }
            )
        } else {*/
            document.getElementById(btnAddEditId).removeAttribute(garrunchoIdAttribute)
            document.getElementById(btnAddEditId).innerHTML = "Adicionar"
            document.getElementById(labGarrunchoTitleId).innerHTML = "Adicionar Garruncho"
        //}
    });

    document.getElementById(btnAddEditId).onclick = function(evt) {
        let garrunchoId = -1
        if (this.hasAttribute(garrunchoIdAttribute)) {
            garrunchoId = parseInt(this.getAttribute(garrunchoIdAttribute))
        }

        const form = document.getElementById(frmGarrunchoId);

        let data = form.serializeFormJSON();

        data = treatFormData(data);

        if (garrunchoId > -1) {
            editGarruncho(
                garrunchoId,
                data,
                function() {
                    setLoading(true);
                    //setLoadingModal(true, document.getElementById(mdlGarrunchoId)); // TODO Review
                }, function(result) {
                    //setLoadingModal(false, document.getElementById(mdlGarrunchoId)); // TODO Review
                    modal.hide();
                    if (result) {
                        getGarrunchosAndLoad()
                        showMessage("O/A Garruncho foi atualizado!", 1);
                    } else {
                        showMessage("Algo deu errado!", 2);
                    }
                    setLoading(false);
                }, function(error) {
                    //setLoadingModal(false, document.getElementById(mdlGarrunchoId)); // TODO Review
                    modal.hide();
                    showMessage("Algo deu errado!", 2);
                    //console.error(error);
                    setLoading(false);
                }
            )
        } else {
            addGarruncho(
                data,
                function() {
                    setLoading(true);
                    //setLoadingModal(true, document.getElementById(mdlGarrunchoId)); // TODO Review
                }, function(garrunchoId) {
                    //setLoadingModal(false, document.getElementById(mdlGarrunchoId)); // TODO Review
                    modal.hide();
                    if (garrunchoId > 0) {
                        getGarrunchosAndLoad();
                        showMessage("O/A Garruncho foi atualizado!", 1);
                    } else {
                        showMessage("Algo deu errado!", 2);
                    }
                    setLoading(false);
                }, function(error) {
                    //setLoadingModal(false, document.getElementById(mdlGarrunchoId)); // TODO Review
                    modal.hide();
                    showMessage("Algo deu errado!", 2);
                    //console.error(error);
                    setLoading(false);
                }
            )
        }
    };
});