<div id="mdl-add-edit-garruncho" class="modal fade" tabindex="-1" aria-labelledby="add-edit-garruncho-title" aria-hidden="true" >
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="add-edit-garruncho-title">Adicionar Garruncho</h5>
                <button type="button" class="btn-close" data-mdb-dismiss="modal" aria-label="Fechar"></button>
            </div>
            <div class="modal-body">
                <form id="form-garruncho">
                   <div class="row">
                       <div class="col-12 col-sm-4 col-md-4 col-lg-4">
                            <div class="form-outline">
                                <input name="tipo" type="number" id="tipo" class="form-control" />
                                <label class="form-label" for="tipo">Tipo</label>
                            </div>
                        </div>
                   </div>
               </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-danger" data-mdb-dismiss="modal">
                    Cancelar
                </button>
                <button id="add-edit-garruncho" garrunchoId="-1" type="button" class="btn btn-primary">Adicionar</button>
            </div>
        </div>
    </div>
</div>